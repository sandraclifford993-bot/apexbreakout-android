export type MarketCategory = 'forex' | 'gold' | 'crypto';

export type Timeframe = '15m' | '4h';

export type TrendDirection = 'BULLISH' | 'BEARISH' | 'NEUTRAL';

export type SignalType = 'BUY' | 'SELL';

export type SignalStatus = 'PENDING_RETEST' | 'ACTIVE' | 'PROFIT_HIT' | 'LOSS_HIT' | 'INVALIDATED';

export interface Candle {
  time: number; // Unix timestamp in seconds
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface MarketPair {
  id: string;
  symbol: string;
  name: string;
  category: MarketCategory;
  baseAsset: string;
  quoteAsset: string;
  decimals: number;
  pipSize: number;
  yahooSymbol: string;
  binanceSymbol?: string;
  fallbackBasePrice: number;
  currentPrice?: number;
  priceChange24h?: number;
  lastUpdated?: number;
}

export interface Trendline {
  type: 'RESISTANCE' | 'SUPPORT';
  startIndex: number;
  endIndex: number;
  startTime: number;
  endTime: number;
  startPrice: number;
  endPrice: number;
  slope: number;
  intercept: number;
  touches: number;
}

export interface TrendAnalysis4H {
  direction: TrendDirection;
  ema50: number;
  ema200: number;
  structure: 'HIGHER_HIGHS' | 'LOWER_LOWS' | 'RANGING';
  strengthPercent: number;
  summary: string;
}

export interface BreakoutRetestSignal {
  id: string;
  pairId: string;
  pairSymbol: string;
  category: MarketCategory;
  direction: SignalType;
  status: SignalStatus;
  createdAt: number;
  resolvedAt?: number;
  // 4H Trend requirement
  trend4H: TrendDirection;
  trend4HSummary: string;
  timeframe: '15m';
  // Breakout details
  breakoutCandleTime: number;
  breakoutPrice: number;
  trendlineLevelAtBreakout: number;
  trendline: Trendline;
  // Retest details
  retestCandleTime?: number;
  retestPrice?: number;
  retestConfirmed: boolean;
  retestNote: string;
  // Exact 1:3 RR Trade Parameters
  entryPrice: number;
  stopLossPrice: number;
  takeProfitPrice: number;
  riskAmount: number;
  rewardAmount: number;
  riskRewardRatio: number; // strictly 3.0
  riskPips: number;
  rewardPips: number;
  // Live Tracking
  currentPrice: number;
  currentPnlPips: number;
  currentRMultiple: number; // e.g. +1.4R or -0.5R
  maxFavorableExcursionR: number; // Highest R reached
  maxAdverseExcursionR: number; // Lowest R reached

  // Signal Timing & Interval
  timeIntervalGiven: string; // e.g. "15M (15-Minute Chart)"
  macroInterval: string; // "4H (4-Hour Chart)"
  isNewSignal?: boolean; // true if created recently (< 2 hours)

  // Explicit Validity State
  isValid: boolean; // true if still actionable / running in market
  validityStatus: 'VALID_ACTIVE' | 'VALID_PENDING_RETEST' | 'NOT_VALID_PROFIT_HIT' | 'NOT_VALID_STOPPED' | 'NOT_VALID_EXPIRED';
  validityReason: string; // Detailed human-readable explanation of validity
  durationFormatted?: string; // e.g. "Running 25m" or "Resolved in 2h 15m"

  notes?: string;
}

export interface PerformanceStats {
  totalSignals: number;
  activeSignals: number;
  pendingRetestSignals: number;
  profitHits: number;
  lossHits: number;
  winRate: number; // percentage (0 - 100)
  netR: number; // Total R profit (wins give +3R, losses -1R)
  profitFactor: number;
  totalPipsWon: number;
  totalPipsLost: number;
  netPips: number;
}
