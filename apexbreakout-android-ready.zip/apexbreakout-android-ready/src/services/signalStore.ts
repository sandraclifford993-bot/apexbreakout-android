import confetti from 'canvas-confetti';
import { BreakoutRetestSignal, PerformanceStats } from '../types/market';
import { soundEffects } from './soundEffects';

const STORAGE_KEY = 'apex_breakout_signals_records_v2';

export function formatRelativeTime(timestamp: number): string {
  const diffSec = Math.floor((Date.now() - timestamp) / 1000);
  if (diffSec < 60) return 'Just now';
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHours = Math.floor(diffMin / 60);
  if (diffHours < 24) return `${diffHours}h ${diffMin % 60}m ago`;
  const diffDays = Math.floor(diffHours / 24);
  return `${diffDays}d ago`;
}

export function formatExactDateTime(timestamp: number): string {
  const d = new Date(timestamp);
  return d.toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    timeZoneName: 'short',
  });
}

// Seed historical recorded signals demonstrating every outcome (Profit Hit, Loss Hit, Active, Pending Retest)
const SEED_SIGNALS: BreakoutRetestSignal[] = [
  {
    id: 'SIG-BTC-USD-BUY-1718012',
    pairId: 'BTC-USD',
    pairSymbol: 'BTC/USD',
    category: 'crypto',
    direction: 'BUY',
    status: 'PROFIT_HIT',
    createdAt: Date.now() - 1000 * 60 * 60 * 18,
    resolvedAt: Date.now() - 1000 * 60 * 60 * 6,
    trend4H: 'BULLISH',
    trend4HSummary: '4H Bullish Uptrend confirmed. Price above 50 EMA with Higher Highs.',
    timeframe: '15m',
    timeIntervalGiven: '15M (15-Minute Candle)',
    macroInterval: '4H (4-Hour Macro Trend)',
    isNewSignal: false,
    isValid: false,
    validityStatus: 'NOT_VALID_PROFIT_HIT',
    validityReason: 'NO LONGER VALID (CLOSED): Target Take Profit (+3R) hit. Strategy target reached.',
    durationFormatted: 'Resolved in 12h 0m',
    breakoutCandleTime: Math.floor(Date.now() / 1000) - 64800,
    breakoutPrice: 86420.0,
    trendlineLevelAtBreakout: 86350.0,
    trendline: {
      type: 'RESISTANCE',
      startIndex: 12,
      endIndex: 28,
      startTime: Math.floor(Date.now() / 1000) - 90000,
      endTime: Math.floor(Date.now() / 1000) - 68000,
      startPrice: 87100.0,
      endPrice: 86380.0,
      slope: -0.045,
      intercept: 87100.0,
      touches: 3,
    },
    retestCandleTime: Math.floor(Date.now() / 1000) - 63000,
    retestPrice: 86480.0,
    retestConfirmed: true,
    retestNote: 'Confirmed 15m pullback retest off broken resistance at 86,390. Bullish hammer printed.',
    entryPrice: 86520.0,
    stopLossPrice: 85920.0,
    takeProfitPrice: 88320.0,
    riskAmount: 600.0,
    rewardAmount: 1800.0,
    riskRewardRatio: 3.0,
    riskPips: 600,
    rewardPips: 1800,
    currentPrice: 88340.0,
    currentPnlPips: 1800,
    currentRMultiple: 3.0,
    maxFavorableExcursionR: 3.05,
    maxAdverseExcursionR: -0.15,
    notes: 'Flawless 15m retest off 4H bull trend support. Hit 1:3 Take Profit target.',
  },
  {
    id: 'SIG-XAU-USD-BUY-1718013',
    pairId: 'XAU-USD',
    pairSymbol: 'XAU/USD',
    category: 'gold',
    direction: 'BUY',
    status: 'PROFIT_HIT',
    createdAt: Date.now() - 1000 * 60 * 60 * 28,
    resolvedAt: Date.now() - 1000 * 60 * 60 * 12,
    trend4H: 'BULLISH',
    trend4HSummary: '4H Bullish Uptrend confirmed. 50 EMA above 200 EMA.',
    timeframe: '15m',
    timeIntervalGiven: '15M (15-Minute Candle)',
    macroInterval: '4H (4-Hour Macro Trend)',
    isNewSignal: false,
    isValid: false,
    validityStatus: 'NOT_VALID_PROFIT_HIT',
    validityReason: 'NO LONGER VALID (CLOSED): Target Take Profit (+3R) hit. Strategy target reached.',
    durationFormatted: 'Resolved in 16h 0m',
    breakoutCandleTime: Math.floor(Date.now() / 1000) - 100800,
    breakoutPrice: 2718.5,
    trendlineLevelAtBreakout: 2717.8,
    trendline: {
      type: 'RESISTANCE',
      startIndex: 10,
      endIndex: 26,
      startTime: Math.floor(Date.now() / 1000) - 130000,
      endTime: Math.floor(Date.now() / 1000) - 105000,
      startPrice: 2732.0,
      endPrice: 2718.0,
      slope: -0.875,
      intercept: 2732.0,
      touches: 3,
    },
    retestCandleTime: Math.floor(Date.now() / 1000) - 99000,
    retestPrice: 2720.0,
    retestConfirmed: true,
    retestNote: 'Tested broken resistance level at 2718.20 and held as new support. Fired signal.',
    entryPrice: 2721.0,
    stopLossPrice: 2714.0,
    takeProfitPrice: 2742.0,
    riskAmount: 7.0,
    rewardAmount: 21.0,
    riskRewardRatio: 3.0,
    riskPips: 70,
    rewardPips: 210,
    currentPrice: 2742.5,
    currentPnlPips: 210,
    currentRMultiple: 3.0,
    maxFavorableExcursionR: 3.1,
    maxAdverseExcursionR: -0.2,
    notes: 'Gold breakout & retest cleanly reached +3.0R TP.',
  },
  {
    id: 'SIG-EUR-USD-SELL-1718014',
    pairId: 'EUR-USD',
    pairSymbol: 'EUR/USD',
    category: 'forex',
    direction: 'SELL',
    status: 'PROFIT_HIT',
    createdAt: Date.now() - 1000 * 60 * 60 * 36,
    resolvedAt: Date.now() - 1000 * 60 * 60 * 20,
    trend4H: 'BEARISH',
    trend4HSummary: '4H Bearish Downtrend. Price below 50 EMA with Lower Lows.',
    timeframe: '15m',
    timeIntervalGiven: '15M (15-Minute Candle)',
    macroInterval: '4H (4-Hour Macro Trend)',
    isNewSignal: false,
    isValid: false,
    validityStatus: 'NOT_VALID_PROFIT_HIT',
    validityReason: 'NO LONGER VALID (CLOSED): Take Profit (+3R) successfully reached.',
    durationFormatted: 'Resolved in 16h 0m',
    breakoutCandleTime: Math.floor(Date.now() / 1000) - 130000,
    breakoutPrice: 1.0875,
    trendlineLevelAtBreakout: 1.0878,
    trendline: {
      type: 'SUPPORT',
      startIndex: 8,
      endIndex: 22,
      startTime: Math.floor(Date.now() / 1000) - 160000,
      endTime: Math.floor(Date.now() / 1000) - 135000,
      startPrice: 1.084,
      endPrice: 1.0875,
      slope: 0.00025,
      intercept: 1.084,
      touches: 3,
    },
    retestCandleTime: Math.floor(Date.now() / 1000) - 128000,
    retestPrice: 1.0872,
    retestConfirmed: true,
    retestNote: 'Pullback retest into broken ascending support at 1.0876 printed bearish engulfing.',
    entryPrice: 1.0868,
    stopLossPrice: 1.0886,
    takeProfitPrice: 1.0814,
    riskAmount: 0.0018,
    rewardAmount: 0.0054,
    riskRewardRatio: 3.0,
    riskPips: 18.0,
    rewardPips: 54.0,
    currentPrice: 1.0812,
    currentPnlPips: 54.0,
    currentRMultiple: 3.0,
    maxFavorableExcursionR: 3.0,
    maxAdverseExcursionR: -0.3,
    notes: 'EUR/USD 15m bear retest aligned with 4H trend hit full 54 pip TP.',
  },
  {
    id: 'SIG-GBP-USD-BUY-1718015',
    pairId: 'GBP-USD',
    pairSymbol: 'GBP/USD',
    category: 'forex',
    direction: 'BUY',
    status: 'LOSS_HIT',
    createdAt: Date.now() - 1000 * 60 * 60 * 42,
    resolvedAt: Date.now() - 1000 * 60 * 60 * 38,
    trend4H: 'BULLISH',
    trend4HSummary: '4H Bullish Uptrend confirmed.',
    timeframe: '15m',
    timeIntervalGiven: '15M (15-Minute Candle)',
    macroInterval: '4H (4-Hour Macro Trend)',
    isNewSignal: false,
    isValid: false,
    validityStatus: 'NOT_VALID_STOPPED',
    validityReason: 'NO LONGER VALID (CLOSED): Stop Loss (-1R) hit. Risk strictly capped at -1.0R.',
    durationFormatted: 'Resolved in 4h 0m',
    breakoutCandleTime: Math.floor(Date.now() / 1000) - 150000,
    breakoutPrice: 1.2995,
    trendlineLevelAtBreakout: 1.299,
    trendline: {
      type: 'RESISTANCE',
      startIndex: 10,
      endIndex: 25,
      startTime: Math.floor(Date.now() / 1000) - 180000,
      endTime: Math.floor(Date.now() / 1000) - 152000,
      startPrice: 1.304,
      endPrice: 1.2992,
      slope: -0.00032,
      intercept: 1.304,
      touches: 2,
    },
    retestCandleTime: Math.floor(Date.now() / 1000) - 148000,
    retestPrice: 1.2998,
    retestConfirmed: true,
    retestNote: 'Retest bounce occurred; but high-impact news caused sudden reverse into SL.',
    entryPrice: 1.3002,
    stopLossPrice: 1.2982,
    takeProfitPrice: 1.3062,
    riskAmount: 0.002,
    rewardAmount: 0.006,
    riskRewardRatio: 3.0,
    riskPips: 20.0,
    rewardPips: 60.0,
    currentPrice: 1.2978,
    currentPnlPips: -20.0,
    currentRMultiple: -1.0,
    maxFavorableExcursionR: 0.8,
    maxAdverseExcursionR: -1.0,
    notes: 'Tight Stop Loss executed properly at -1.0R risk limit, preserving capital.',
  },
  {
    id: 'SIG-USD-JPY-SELL-1718016',
    pairId: 'USD-JPY',
    pairSymbol: 'USD/JPY',
    category: 'forex',
    direction: 'SELL',
    status: 'PROFIT_HIT',
    createdAt: Date.now() - 1000 * 60 * 60 * 50,
    resolvedAt: Date.now() - 1000 * 60 * 60 * 30,
    trend4H: 'BEARISH',
    trend4HSummary: '4H Bearish trend below 50 EMA.',
    timeframe: '15m',
    timeIntervalGiven: '15M (15-Minute Candle)',
    macroInterval: '4H (4-Hour Macro Trend)',
    isNewSignal: false,
    isValid: false,
    validityStatus: 'NOT_VALID_PROFIT_HIT',
    validityReason: 'NO LONGER VALID (CLOSED): Target Take Profit (+3R) successfully reached.',
    durationFormatted: 'Resolved in 20h 0m',
    breakoutCandleTime: Math.floor(Date.now() / 1000) - 180000,
    breakoutPrice: 153.2,
    trendlineLevelAtBreakout: 153.25,
    trendline: {
      type: 'SUPPORT',
      startIndex: 8,
      endIndex: 20,
      startTime: Math.floor(Date.now() / 1000) - 210000,
      endTime: Math.floor(Date.now() / 1000) - 182000,
      startPrice: 152.6,
      endPrice: 153.22,
      slope: 0.05,
      intercept: 152.6,
      touches: 3,
    },
    retestCandleTime: Math.floor(Date.now() / 1000) - 177000,
    retestPrice: 153.15,
    retestConfirmed: true,
    retestNote: 'Retest of broken trendline confirmed with shooting star rejection bar.',
    entryPrice: 153.1,
    stopLossPrice: 153.5,
    takeProfitPrice: 151.9,
    riskAmount: 0.4,
    rewardAmount: 1.2,
    riskRewardRatio: 3.0,
    riskPips: 40.0,
    rewardPips: 120.0,
    currentPrice: 151.85,
    currentPnlPips: 120.0,
    currentRMultiple: 3.0,
    maxFavorableExcursionR: 3.0,
    maxAdverseExcursionR: -0.25,
    notes: 'Clean 120 pip drop hitting exact 1:3 RR target on USD/JPY.',
  },
  {
    id: 'SIG-SOL-USD-BUY-1718017',
    pairId: 'SOL-USD',
    pairSymbol: 'SOL/USD',
    category: 'crypto',
    direction: 'BUY',
    status: 'ACTIVE',
    createdAt: Date.now() - 1000 * 60 * 35, // 35 minutes ago
    trend4H: 'BULLISH',
    trend4HSummary: '4H Bullish Uptrend confirmed. Above 50 & 200 EMA.',
    timeframe: '15m',
    timeIntervalGiven: '15M (15-Minute Candle)',
    macroInterval: '4H (4-Hour Macro Trend)',
    isNewSignal: true,
    isValid: true,
    validityStatus: 'VALID_ACTIVE',
    validityReason: 'STILL VALID: Active in market, currently floating +1.2R in profit towards +3R target.',
    durationFormatted: 'Active for 35m',
    breakoutCandleTime: Math.floor(Date.now() / 1000) - 2700,
    breakoutPrice: 171.2,
    trendlineLevelAtBreakout: 170.8,
    trendline: {
      type: 'RESISTANCE',
      startIndex: 15,
      endIndex: 26,
      startTime: Math.floor(Date.now() / 1000) - 12000,
      endTime: Math.floor(Date.now() / 1000) - 3600,
      startPrice: 173.5,
      endPrice: 171.0,
      slope: -0.22,
      intercept: 173.5,
      touches: 3,
    },
    retestCandleTime: Math.floor(Date.now() / 1000) - 2100,
    retestPrice: 171.35,
    retestConfirmed: true,
    retestNote: 'Retest bounce printed bullish hammer at 171.00. Signal triggered.',
    entryPrice: 171.4,
    stopLossPrice: 169.8,
    takeProfitPrice: 176.2,
    riskAmount: 1.6,
    rewardAmount: 4.8,
    riskRewardRatio: 3.0,
    riskPips: 32,
    rewardPips: 96,
    currentPrice: 173.32,
    currentPnlPips: 38.4,
    currentRMultiple: 1.2,
    maxFavorableExcursionR: 1.35,
    maxAdverseExcursionR: -0.1,
    notes: 'New 15m breakout & retest signal actively advancing toward 1:3 RR TP.',
  },
];

class SignalStore {
  private signals: BreakoutRetestSignal[] = [];
  private listeners: (() => void)[] = [];

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          this.signals = parsed;
          return;
        }
      }
    } catch (e) {
      console.warn('Could not load signals from localStorage', e);
    }
    // Fallback to seed records
    this.signals = [...SEED_SIGNALS];
    this.saveToStorage();
  }

  private saveToStorage() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.signals));
    } catch (e) {
      console.warn('Could not save signals to localStorage', e);
    }
    this.notify();
  }

  public subscribe(listener: () => void) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach((fn) => fn());
  }

  public getSignals(): BreakoutRetestSignal[] {
    return [...this.signals];
  }

  // Register or update a signal generated by the scanner
  public upsertSignal(signal: BreakoutRetestSignal): { isNew: boolean; isProfitHit: boolean; isLossHit: boolean } {
    const existingIndex = this.signals.findIndex((s) => s.id === signal.id);
    let isNew = false;
    let isProfitHit = false;
    let isLossHit = false;

    if (existingIndex === -1) {
      isNew = true;
      // Mark as new signal
      signal.isNewSignal = true;
      this.signals.unshift(signal);
      if (signal.status === 'ACTIVE') {
        soundEffects.playSignalFired(signal.direction);
      }
    } else {
      const existing = this.signals[existingIndex];
      // Check if transitioned to PROFIT_HIT
      if (existing.status !== 'PROFIT_HIT' && signal.status === 'PROFIT_HIT') {
        isProfitHit = true;
        signal.isValid = false;
        signal.validityStatus = 'NOT_VALID_PROFIT_HIT';
        signal.validityReason = 'NO LONGER VALID (CLOSED): Take Profit (+3.0R) hit. Trade completed.';
        soundEffects.playProfitHit();
        this.triggerConfetti();
      } else if (existing.status !== 'LOSS_HIT' && signal.status === 'LOSS_HIT') {
        isLossHit = true;
        signal.isValid = false;
        signal.validityStatus = 'NOT_VALID_STOPPED';
        signal.validityReason = 'NO LONGER VALID (CLOSED): Stop Loss (-1.0R) hit. Position closed.';
        soundEffects.playLossHit();
      }

      this.signals[existingIndex] = {
        ...existing,
        ...signal,
        createdAt: existing.createdAt, // keep original timestamp
      };
    }

    this.saveToStorage();
    return { isNew, isProfitHit, isLossHit };
  }

  // Update live ticks against all active signals to check for TP/SL hits
  public updateLivePrice(pairId: string, currentPrice: number) {
    let changed = false;

    for (let i = 0; i < this.signals.length; i++) {
      const sig = this.signals[i];
      if (sig.pairId !== pairId || sig.status !== 'ACTIVE') continue;

      const diff = sig.direction === 'BUY' ? currentPrice - sig.entryPrice : sig.entryPrice - currentPrice;
      const pipMultiplier = sig.category === 'forex' && sig.pairSymbol.includes('JPY') ? 100 : sig.category === 'forex' ? 10000 : 1;
      const currentPnlPips = Math.round(diff * pipMultiplier * 10) / 10;
      const currentR = sig.riskAmount > 0 ? Number((diff / sig.riskAmount).toFixed(2)) : 0;

      sig.currentPrice = currentPrice;
      sig.currentPnlPips = currentPnlPips;
      sig.currentRMultiple = currentR;
      sig.maxFavorableExcursionR = Math.max(sig.maxFavorableExcursionR || 0, currentR);
      sig.maxAdverseExcursionR = Math.min(sig.maxAdverseExcursionR || 0, currentR);

      // Check Take Profit Hit
      if (
        (sig.direction === 'BUY' && currentPrice >= sig.takeProfitPrice) ||
        (sig.direction === 'SELL' && currentPrice <= sig.takeProfitPrice)
      ) {
        sig.status = 'PROFIT_HIT';
        sig.resolvedAt = Date.now();
        sig.currentRMultiple = 3.0; // Guaranteed 1:3 RR
        sig.isValid = false;
        sig.validityStatus = 'NOT_VALID_PROFIT_HIT';
        sig.validityReason = 'NO LONGER VALID (CLOSED): Take Profit (+3.0R) reached! Strategy target hit.';
        sig.durationFormatted = `Resolved in ${Math.max(1, Math.floor((sig.resolvedAt - sig.createdAt) / 60000))}m`;
        changed = true;
        soundEffects.playProfitHit();
        this.triggerConfetti();
      }
      // Check Stop Loss Hit
      else if (
        (sig.direction === 'BUY' && currentPrice <= sig.stopLossPrice) ||
        (sig.direction === 'SELL' && currentPrice >= sig.stopLossPrice)
      ) {
        sig.status = 'LOSS_HIT';
        sig.resolvedAt = Date.now();
        sig.currentRMultiple = -1.0;
        sig.isValid = false;
        sig.validityStatus = 'NOT_VALID_STOPPED';
        sig.validityReason = 'NO LONGER VALID (CLOSED): Stop Loss (-1.0R) hit. Risk capped at -1R.';
        sig.durationFormatted = `Resolved in ${Math.max(1, Math.floor((sig.resolvedAt - sig.createdAt) / 60000))}m`;
        changed = true;
        soundEffects.playLossHit();
      } else {
        changed = true;
      }
    }

    if (changed) {
      this.saveToStorage();
    }
  }

  public triggerConfetti() {
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#10b981', '#34d399', '#6ee7b7', '#f59e0b', '#3b82f6'],
      });
    } catch (e) {
      // ignore
    }
  }

  public deleteSignal(id: string) {
    this.signals = this.signals.filter((s) => s.id !== id);
    this.saveToStorage();
  }

  public clearAll() {
    this.signals = [];
    this.saveToStorage();
  }

  public resetToSeeds() {
    this.signals = [...SEED_SIGNALS];
    this.saveToStorage();
  }

  // Calculate live overall stats
  public getPerformanceStats(): PerformanceStats {
    let profitHits = 0;
    let lossHits = 0;
    let activeSignals = 0;
    let pendingRetestSignals = 0;
    let totalPipsWon = 0;
    let totalPipsLost = 0;
    let netR = 0;

    for (const sig of this.signals) {
      if (sig.status === 'PROFIT_HIT') {
        profitHits++;
        totalPipsWon += sig.rewardPips;
        netR += 3.0; // 1:3 reward
      } else if (sig.status === 'LOSS_HIT') {
        lossHits++;
        totalPipsLost += sig.riskPips;
        netR -= 1.0; // 1R loss
      } else if (sig.status === 'ACTIVE') {
        activeSignals++;
      } else if (sig.status === 'PENDING_RETEST') {
        pendingRetestSignals++;
      }
    }

    const totalClosed = profitHits + lossHits;
    const winRate = totalClosed > 0 ? Math.round((profitHits / totalClosed) * 1000) / 10 : 0;
    const profitFactor =
      lossHits > 0
        ? Math.round(((profitHits * 3.0) / (lossHits * 1.0)) * 100) / 100
        : profitHits > 0
        ? 9.99
        : 1.0;

    return {
      totalSignals: this.signals.length,
      activeSignals,
      pendingRetestSignals,
      profitHits,
      lossHits,
      winRate,
      netR: Math.round(netR * 10) / 10,
      profitFactor,
      totalPipsWon,
      totalPipsLost,
      netPips: totalPipsWon - totalPipsLost,
    };
  }
}

export const signalStore = new SignalStore();
