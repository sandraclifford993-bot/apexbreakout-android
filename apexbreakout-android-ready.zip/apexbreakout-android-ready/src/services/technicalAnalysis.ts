import {
  Candle,
  MarketPair,
  TrendDirection,
  TrendAnalysis4H,
  Trendline,
  BreakoutRetestSignal,
} from '../types/market';
import { calculatePips } from './marketPairs';

// Calculate Exponential Moving Average
export function calculateEMA(candles: Candle[], period: number): number[] {
  if (candles.length === 0) return [];
  const k = 2 / (period + 1);
  const emaArray: number[] = [];

  // Simple initial SMA
  let sum = 0;
  const initialPeriod = Math.min(period, candles.length);
  for (let i = 0; i < initialPeriod; i++) {
    sum += candles[i].close;
  }
  let currentEMA = sum / initialPeriod;
  emaArray.push(currentEMA);

  for (let i = initialPeriod; i < candles.length; i++) {
    currentEMA = candles[i].close * k + currentEMA * (1 - k);
    emaArray.push(currentEMA);
  }

  // Pad front if candles.length > initialPeriod
  const padCount = candles.length - emaArray.length;
  const padding = Array(padCount).fill(emaArray[0]);
  return [...padding, ...emaArray];
}

// Identify Pivot Highs and Pivot Lows
export interface PivotPoint {
  index: number;
  time: number;
  price: number;
  type: 'HIGH' | 'LOW';
}

export function findPivots(candles: Candle[], leftBars: number = 3, rightBars: number = 2): PivotPoint[] {
  const pivots: PivotPoint[] = [];

  for (let i = leftBars; i < candles.length - rightBars; i++) {
    const currentHigh = candles[i].high;
    const currentLow = candles[i].low;

    let isHigh = true;
    let isLow = true;

    for (let j = i - leftBars; j <= i + rightBars; j++) {
      if (j === i) continue;
      if (candles[j].high >= currentHigh) isHigh = false;
      if (candles[j].low <= currentLow) isLow = false;
    }

    if (isHigh) {
      pivots.push({ index: i, time: candles[i].time, price: currentHigh, type: 'HIGH' });
    }
    if (isLow) {
      pivots.push({ index: i, time: candles[i].time, price: currentLow, type: 'LOW' });
    }
  }

  return pivots;
}

// 4-Hour Market Trend Analyzer
export function analyze4HTrend(candles4H: Candle[]): TrendAnalysis4H {
  if (candles4H.length < 15) {
    return {
      direction: 'NEUTRAL',
      ema50: 0,
      ema200: 0,
      structure: 'RANGING',
      strengthPercent: 50,
      summary: 'Insufficient 4H candle data for high-confidence trend validation.',
    };
  }

  const ema50Series = calculateEMA(candles4H, 50);
  const ema200Series = calculateEMA(candles4H, 200);

  const lastCandle = candles4H[candles4H.length - 1];
  const lastEma50 = ema50Series[ema50Series.length - 1];
  const lastEma200 = ema200Series[ema200Series.length - 1];

  // Market Structure via recent pivots on 4H
  const pivots = findPivots(candles4H, 2, 1);
  const highs = pivots.filter((p) => p.type === 'HIGH').slice(-3);
  const lows = pivots.filter((p) => p.type === 'LOW').slice(-3);

  let structure: 'HIGHER_HIGHS' | 'LOWER_LOWS' | 'RANGING' = 'RANGING';

  if (highs.length >= 2 && lows.length >= 2) {
    const isHigherHighs = highs[highs.length - 1].price > highs[highs.length - 2].price;
    const isHigherLows = lows[lows.length - 1].price > lows[lows.length - 2].price;
    const isLowerHighs = highs[highs.length - 1].price < highs[highs.length - 2].price;
    const isLowerLows = lows[lows.length - 1].price < lows[lows.length - 2].price;

    if (isHigherHighs && isHigherLows) {
      structure = 'HIGHER_HIGHS';
    } else if (isLowerHighs && isLowerLows) {
      structure = 'LOWER_LOWS';
    }
  }

  let direction: TrendDirection = 'NEUTRAL';
  let strengthPercent = 50;

  // Bullish Criteria: Price > 50 EMA, 50 EMA > 200 EMA (or strong higher-high structure)
  if (lastCandle.close > lastEma50 && (lastEma50 >= lastEma200 || structure === 'HIGHER_HIGHS')) {
    direction = 'BULLISH';
    strengthPercent = structure === 'HIGHER_HIGHS' ? 88 : 72;
  } else if (lastCandle.close < lastEma50 && (lastEma50 <= lastEma200 || structure === 'LOWER_LOWS')) {
    direction = 'BEARISH';
    strengthPercent = structure === 'LOWER_LOWS' ? 88 : 72;
  } else {
    direction = 'NEUTRAL';
    strengthPercent = 45;
  }

  const summary =
    direction === 'BULLISH'
      ? `4H Bullish Uptrend confirmed. Price (${lastCandle.close.toFixed(
          2
        )}) above 50 EMA (${lastEma50.toFixed(2)}) with ${structure.replace('_', ' ')}. Only LONG breakout & retest signals authorized.`
      : direction === 'BEARISH'
      ? `4H Bearish Downtrend confirmed. Price (${lastCandle.close.toFixed(
          2
        )}) below 50 EMA (${lastEma50.toFixed(2)}) with ${structure.replace('_', ' ')}. Only SHORT breakdown & retest signals authorized.`
      : `4H Trend is Neutral / Consolidating. Signals paused to protect capital against choppy conditions.`;

  return {
    direction,
    ema50: lastEma50,
    ema200: lastEma200,
    structure,
    strengthPercent,
    summary,
  };
}

// Detect 15-Minute Trendline matching 4H trend direction
export function detect15MTrendline(
  candles15M: Candle[],
  trend4H: TrendDirection
): Trendline | null {
  if (candles15M.length < 25 || trend4H === 'NEUTRAL') return null;

  const pivots = findPivots(candles15M, 3, 2);

  if (trend4H === 'BULLISH') {
    // For Bullish signal: look for descending resistance trendline connecting swing highs
    const highs = pivots.filter((p) => p.type === 'HIGH');
    if (highs.length < 2) return null;

    // Scan pairs of recent highs to find a descending resistance line
    for (let i = highs.length - 2; i >= Math.max(0, highs.length - 6); i--) {
      for (let j = highs.length - 1; j > i; j--) {
        const p1 = highs[i];
        const p2 = highs[j];

        if (p2.price < p1.price && p2.index - p1.index >= 4) {
          const slope = (p2.price - p1.price) / (p2.index - p1.index);
          const intercept = p1.price - slope * p1.index;

          // Check touches and ensure line is not cut prematurely
          let touches = 2;
          let valid = true;

          for (let k = p1.index; k <= p2.index; k++) {
            const lineVal = slope * k + intercept;
            // No candle close significantly above this resistance line before breakout
            if (candles15M[k].close > lineVal * 1.002) {
              valid = false;
              break;
            }
            if (Math.abs(candles15M[k].high - lineVal) / lineVal < 0.002) {
              touches++;
            }
          }

          if (valid) {
            return {
              type: 'RESISTANCE',
              startIndex: p1.index,
              endIndex: p2.index,
              startTime: p1.time,
              endTime: p2.time,
              startPrice: p1.price,
              endPrice: p2.price,
              slope,
              intercept,
              touches,
            };
          }
        }
      }
    }
  } else if (trend4H === 'BEARISH') {
    // For Bearish signal: look for ascending support trendline connecting swing lows
    const lows = pivots.filter((p) => p.type === 'LOW');
    if (lows.length < 2) return null;

    for (let i = lows.length - 2; i >= Math.max(0, lows.length - 6); i--) {
      for (let j = lows.length - 1; j > i; j--) {
        const p1 = lows[i];
        const p2 = lows[j];

        if (p2.price > p1.price && p2.index - p1.index >= 4) {
          const slope = (p2.price - p1.price) / (p2.index - p1.index);
          const intercept = p1.price - slope * p1.index;

          let touches = 2;
          let valid = true;

          for (let k = p1.index; k <= p2.index; k++) {
            const lineVal = slope * k + intercept;
            // No candle close significantly below this support line before breakout
            if (candles15M[k].close < lineVal * 0.998) {
              valid = false;
              break;
            }
            if (Math.abs(candles15M[k].low - lineVal) / lineVal < 0.002) {
              touches++;
            }
          }

          if (valid) {
            return {
              type: 'SUPPORT',
              startIndex: p1.index,
              endIndex: p2.index,
              startTime: p1.time,
              endTime: p2.time,
              startPrice: p1.price,
              endPrice: p2.price,
              slope,
              intercept,
              touches,
            };
          }
        }
      }
    }
  }

  return null;
}

// Calculate Average True Range (ATR) for volatility buffer
export function calculateATR(candles: Candle[], period: number = 14): number {
  if (candles.length < 2) return 0;
  const trs: number[] = [];

  for (let i = 1; i < candles.length; i++) {
    const high = candles[i].high;
    const low = candles[i].low;
    const prevClose = candles[i - 1].close;
    const tr = Math.max(high - low, Math.abs(high - prevClose), Math.abs(low - prevClose));
    trs.push(tr);
  }

  const recentTrs = trs.slice(-period);
  return recentTrs.reduce((a, b) => a + b, 0) / recentTrs.length;
}

// Detect Trendline Breakout AND 15M Retest, then construct 1:3 RR Signal
export function scanTrendlineBreakoutAndRetest(
  pair: MarketPair,
  candles15M: Candle[],
  trend4HAnalysis: TrendAnalysis4H
): BreakoutRetestSignal | null {
  const trend4H = trend4HAnalysis.direction;
  if (trend4H === 'NEUTRAL' || candles15M.length < 20) return null;

  const trendline = detect15MTrendline(candles15M, trend4H);
  if (!trendline) return null;

  const atr = calculateATR(candles15M, 14);
  const totalBars = candles15M.length;

  // Search recent bars (last 18 bars) for the breakout point
  let breakoutIndex = -1;
  let breakoutPrice = 0;
  let trendlineLevelAtBreakout = 0;

  for (let i = Math.max(trendline.endIndex + 1, totalBars - 18); i < totalBars; i++) {
    const lineVal = trendline.slope * i + trendline.intercept;
    const candle = candles15M[i];

    if (trend4H === 'BULLISH' && trendline.type === 'RESISTANCE') {
      // Bullish Breakout: Candle closes firmly above the descending resistance
      if (candle.close > lineVal && candle.close > candle.open) {
        breakoutIndex = i;
        breakoutPrice = candle.close;
        trendlineLevelAtBreakout = lineVal;
        break;
      }
    } else if (trend4H === 'BEARISH' && trendline.type === 'SUPPORT') {
      // Bearish Breakdown: Candle closes firmly below the ascending support
      if (candle.close < lineVal && candle.close < candle.open) {
        breakoutIndex = i;
        breakoutPrice = candle.close;
        trendlineLevelAtBreakout = lineVal;
        break;
      }
    }
  }

  if (breakoutIndex === -1) return null;

  const breakoutCandle = candles15M[breakoutIndex];
  const currentCandle = candles15M[totalBars - 1];

  // RETEST VERIFICATION:
  // Must check bars after breakoutIndex (breakoutIndex + 1 to current bar)
  let retestConfirmed = false;
  let retestIndex = -1;
  let retestPrice = 0;
  let retestSwingPrice = 0;
  let retestNote = '';

  const retestTolerance = Math.max(pair.pipSize * 3, atr * 0.25);

  for (let j = breakoutIndex + 1; j < totalBars; j++) {
    const bar = candles15M[j];
    const lineValAtBar = trendline.slope * j + trendline.intercept;

    if (trend4H === 'BULLISH') {
      // Bullish Retest: Price pulls back down towards the broken resistance line (now support)
      // Low dips close to or into the breakout level / trendline
      const touchedRetestZone = bar.low <= breakoutPrice + retestTolerance && bar.low >= lineValAtBar - retestTolerance * 1.5;

      // Rejection confirmation: wick rejected lower prices and candle closed back green / above open
      if (touchedRetestZone && (bar.close > bar.open || bar.close > (bar.high + bar.low) / 2)) {
        retestConfirmed = true;
        retestIndex = j;
        retestPrice = bar.close;
        retestSwingPrice = bar.low; // Invalidation point under retest wick
        retestNote = `Confirmed 15m pullback retest off broken resistance at ${bar.low.toFixed(
          pair.decimals
        )}. Bullish rejection candle validated.`;
        break;
      }
    } else if (trend4H === 'BEARISH') {
      // Bearish Retest: Price pulls back up towards broken support line (now resistance)
      const touchedRetestZone = bar.high >= breakoutPrice - retestTolerance && bar.high <= lineValAtBar + retestTolerance * 1.5;

      // Rejection confirmation: wick rejected higher prices and candle closed red / below open
      if (touchedRetestZone && (bar.close < bar.open || bar.close < (bar.high + bar.low) / 2)) {
        retestConfirmed = true;
        retestIndex = j;
        retestPrice = bar.close;
        retestSwingPrice = bar.high; // Invalidation point above retest wick
        retestNote = `Confirmed 15m pullback retest off broken support at ${bar.high.toFixed(
          pair.decimals
        )}. Bearish rejection candle validated.`;
        break;
      }
    }
  }

  // If breakout occurred recently (within last 1-4 bars) but retest hasn't bounced yet:
  const isPendingRetest = !retestConfirmed && totalBars - breakoutIndex <= 5;

  if (!retestConfirmed && !isPendingRetest) {
    // If too many bars passed without a retest, setup expired / invalidated
    return null;
  }

  // Construct 1:3 RR Trade Parameters
  const direction = trend4H === 'BULLISH' ? 'BUY' : 'SELL';
  let entryPrice = retestConfirmed ? retestPrice : currentCandle.close;
  let stopLossPrice = 0;
  let takeProfitPrice = 0;

  // Buffer for spread / structural invalidation
  const buffer = Math.max(pair.pipSize * 4, atr * 0.4);

  if (direction === 'BUY') {
    const swingLow = retestConfirmed ? retestSwingPrice : Math.min(breakoutCandle.low, currentCandle.low);
    stopLossPrice = Number((swingLow - buffer).toFixed(pair.decimals));

    // Ensure realistic risk distance
    const minRisk = Math.max(pair.pipSize * 10, atr * 0.8);
    if (entryPrice - stopLossPrice < minRisk) {
      stopLossPrice = Number((entryPrice - minRisk).toFixed(pair.decimals));
    }

    const riskAmount = entryPrice - stopLossPrice;
    const rewardAmount = riskAmount * 3.0; // STRICT 1:3 RR
    takeProfitPrice = Number((entryPrice + rewardAmount).toFixed(pair.decimals));
  } else {
    const swingHigh = retestConfirmed ? retestSwingPrice : Math.max(breakoutCandle.high, currentCandle.high);
    stopLossPrice = Number((swingHigh + buffer).toFixed(pair.decimals));

    const minRisk = Math.max(pair.pipSize * 10, atr * 0.8);
    if (stopLossPrice - entryPrice < minRisk) {
      stopLossPrice = Number((entryPrice + minRisk).toFixed(pair.decimals));
    }

    const riskAmount = stopLossPrice - entryPrice;
    const rewardAmount = riskAmount * 3.0; // STRICT 1:3 RR
    takeProfitPrice = Number((entryPrice - rewardAmount).toFixed(pair.decimals));
  }

  const riskAmount = Math.abs(entryPrice - stopLossPrice);
  const rewardAmount = Math.abs(takeProfitPrice - entryPrice);
  const riskPips = calculatePips(riskAmount, pair.pipSize);
  const rewardPips = calculatePips(rewardAmount, pair.pipSize);

  // Evaluate Live Status & Validity
  const currentPrice = currentCandle.close;
  let status: 'PENDING_RETEST' | 'ACTIVE' | 'PROFIT_HIT' | 'LOSS_HIT' = 'ACTIVE';

  if (!retestConfirmed) {
    status = 'PENDING_RETEST';
  } else {
    // Check if subsequent bars hit TP or SL
    for (let k = retestIndex; k < totalBars; k++) {
      const b = candles15M[k];
      if (direction === 'BUY') {
        if (b.high >= takeProfitPrice) {
          status = 'PROFIT_HIT';
          break;
        }
        if (b.low <= stopLossPrice) {
          status = 'LOSS_HIT';
          break;
        }
      } else {
        if (b.low <= takeProfitPrice) {
          status = 'PROFIT_HIT';
          break;
        }
        if (b.high >= stopLossPrice) {
          status = 'LOSS_HIT';
          break;
        }
      }
    }
  }

  // Calculate live floating PnL and R-multiple
  const pnlDiff = direction === 'BUY' ? currentPrice - entryPrice : entryPrice - currentPrice;
  const currentPnlPips = calculatePips(pnlDiff, pair.pipSize);
  const currentRMultiple = riskAmount > 0 ? Number((pnlDiff / riskAmount).toFixed(2)) : 0;

  const signalCreatedAt = retestConfirmed && retestIndex !== -1 ? candles15M[retestIndex].time * 1000 : breakoutCandle.time * 1000;
  const signalResolvedAt = status === 'PROFIT_HIT' || status === 'LOSS_HIT' ? currentCandle.time * 1000 : undefined;
  const isNew = Date.now() - signalCreatedAt < 1000 * 60 * 60 * 2; // within last 2 hours

  const isValid = status === 'ACTIVE' || status === 'PENDING_RETEST';
  const validityStatus =
    status === 'ACTIVE'
      ? 'VALID_ACTIVE'
      : status === 'PENDING_RETEST'
      ? 'VALID_PENDING_RETEST'
      : status === 'PROFIT_HIT'
      ? 'NOT_VALID_PROFIT_HIT'
      : 'NOT_VALID_STOPPED';

  const validityReason =
    status === 'ACTIVE'
      ? 'SIGNAL IS STILL VALID: Currently active in market between Entry and TP/SL. 4H trend & 15M breakout confirmed.'
      : status === 'PENDING_RETEST'
      ? 'VALID SETUP (PENDING ENTRY): 15M breakout confirmed; awaiting pullback retest bounce to fill entry order.'
      : status === 'PROFIT_HIT'
      ? 'NO LONGER VALID (CLOSED): Take Profit (+3R) successfully reached. Target achieved.'
      : 'NO LONGER VALID (CLOSED): Stop Loss (-1R) hit. Risk capped at -1R.';

  const elapsedMs = (signalResolvedAt || Date.now()) - signalCreatedAt;
  const elapsedMins = Math.max(1, Math.floor(elapsedMs / (1000 * 60)));
  const durationFormatted =
    status === 'PROFIT_HIT' || status === 'LOSS_HIT'
      ? `Resolved in ${elapsedMins >= 60 ? `${Math.floor(elapsedMins / 60)}h ${elapsedMins % 60}m` : `${elapsedMins}m`}`
      : `Active for ${elapsedMins >= 60 ? `${Math.floor(elapsedMins / 60)}h ${elapsedMins % 60}m` : `${elapsedMins}m`}`;

  const signalId = `SIG-${pair.id}-${direction}-${breakoutCandle.time}`;

  return {
    id: signalId,
    pairId: pair.id,
    pairSymbol: pair.symbol,
    category: pair.category,
    direction,
    status,
    createdAt: signalCreatedAt,
    resolvedAt: signalResolvedAt,
    trend4H,
    trend4HSummary: trend4HAnalysis.summary,
    timeframe: '15m',
    timeIntervalGiven: '15M (15-Minute Candle)',
    macroInterval: '4H (4-Hour Macro Trend)',
    isNewSignal: isNew,
    isValid,
    validityStatus,
    validityReason,
    durationFormatted,
    breakoutCandleTime: breakoutCandle.time,
    breakoutPrice,
    trendlineLevelAtBreakout,
    trendline,
    retestCandleTime: retestConfirmed && retestIndex !== -1 ? candles15M[retestIndex].time : undefined,
    retestPrice: retestConfirmed ? retestPrice : undefined,
    retestConfirmed,
    retestNote: retestConfirmed ? retestNote : 'Breakout confirmed on 15m; awaiting pullback retest before firing signal.',
    entryPrice,
    stopLossPrice,
    takeProfitPrice,
    riskAmount,
    rewardAmount,
    riskRewardRatio: 3.0,
    riskPips,
    rewardPips,
    currentPrice,
    currentPnlPips,
    currentRMultiple,
    maxFavorableExcursionR: Math.max(0, currentRMultiple),
    maxAdverseExcursionR: Math.min(0, currentRMultiple),
  };
}
