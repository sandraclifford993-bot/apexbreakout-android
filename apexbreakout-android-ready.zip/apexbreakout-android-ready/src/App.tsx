import React, { useState, useEffect, useCallback, useRef } from 'react';
import { MarketPair, Timeframe, BreakoutRetestSignal, PerformanceStats } from './types/market';
import { SUPPORTED_PAIRS, formatPrice } from './services/marketPairs';
import { Header } from './components/Header';
import { CandlestickChart } from './components/CandlestickChart';
import { SignalCard } from './components/SignalCard';
import { SignalScanner } from './components/SignalScanner';
import { TradeJournal } from './components/TradeJournal';
import { signalStore } from './services/signalStore';
import { loadPairMarketState, scanAllMarkets, PairMarketState } from './services/marketData';
import {
  TrendingUp,
  TrendingDown,
  Info,
  Layers,
  ShieldCheck,
  Target,
  Clock,
  Sparkles,
  ArrowUpRight,
  ArrowDownRight,
  RefreshCw,
  SlidersHorizontal,
} from 'lucide-react';

export default function App() {
  const [pairs, setPairs] = useState<MarketPair[]>(SUPPORTED_PAIRS);
  const [selectedPair, setSelectedPair] = useState<MarketPair>(SUPPORTED_PAIRS[0]); // BTC/USD
  const [activeTab, setActiveTab] = useState<'terminal' | 'journal' | 'rules'>('terminal');
  const [timeframe, setTimeframe] = useState<Timeframe>('15m');

  const [pairState, setPairState] = useState<PairMarketState | null>(null);
  const [signals, setSignals] = useState<BreakoutRetestSignal[]>(signalStore.getSignals());
  const [stats, setStats] = useState<PerformanceStats>(signalStore.getPerformanceStats());
  const [selectedSignalId, setSelectedSignalId] = useState<string | null>(null);

  const [isScanning, setIsScanning] = useState(false);
  const [scanIntervalSec, setScanIntervalSec] = useState<number>(30);
  const [lastScanTime, setLastScanTime] = useState<number>(Date.now());

  const autoScanTimerRef = useRef<any>(null);

  // Subscribe to signalStore updates
  useEffect(() => {
    const unsubscribe = signalStore.subscribe(() => {
      setSignals(signalStore.getSignals());
      setStats(signalStore.getPerformanceStats());
    });
    return unsubscribe;
  }, []);

  // Load active pair market data
  const loadActivePairData = useCallback(async (pair: MarketPair) => {
    const state = await loadPairMarketState(pair);
    setPairState(state);

    // If pair has an active or recent signal, link selectedSignalId
    if (state.currentSignal) {
      setSelectedSignalId(state.currentSignal.id);
    }
  }, []);

  // Initial load for active pair
  useEffect(() => {
    loadActivePairData(selectedPair);
  }, [selectedPair, loadActivePairData]);

  // Run full multi-asset scan
  const handleTriggerScan = useCallback(async () => {
    setIsScanning(true);
    try {
      await scanAllMarkets(pairs);
      // Reload active pair to reflect latest data
      await loadActivePairData(selectedPair);
      setLastScanTime(Date.now());
    } catch (err) {
      console.warn('Scan error:', err);
    } finally {
      setIsScanning(false);
    }
  }, [pairs, selectedPair, loadActivePairData]);

  // Initial scan on mount
  useEffect(() => {
    handleTriggerScan();
  }, []);

  // Background Auto-Scan Interval Loop
  useEffect(() => {
    if (autoScanTimerRef.current) {
      clearInterval(autoScanTimerRef.current);
      autoScanTimerRef.current = null;
    }

    if (scanIntervalSec > 0) {
      autoScanTimerRef.current = setInterval(() => {
        handleTriggerScan();
      }, scanIntervalSec * 1000);
    }

    return () => {
      if (autoScanTimerRef.current) {
        clearInterval(autoScanTimerRef.current);
      }
    };
  }, [scanIntervalSec, handleTriggerScan]);

  // Handle signal selection from card or ledger
  const handleSelectSignal = (sig: BreakoutRetestSignal) => {
    setSelectedSignalId(sig.id);
    const targetPair = pairs.find((p) => p.id === sig.pairId);
    if (targetPair && targetPair.id !== selectedPair.id) {
      setSelectedPair(targetPair);
    }
    // Switch to terminal tab to inspect chart
    setActiveTab('terminal');
    setTimeframe('15m');
  };

  // Find active signal for the current chart
  const currentSignalForChart =
    signals.find((s) => s.id === selectedSignalId && s.pairId === selectedPair.id) ||
    pairState?.currentSignal ||
    signals.find((s) => s.pairId === selectedPair.id) ||
    null;

  return (
    <div className="min-h-screen bg-[#070a11] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30">
      {/* Institutional Top Header & Live Ticker */}
      <Header
        pairs={pairs}
        selectedPair={selectedPair}
        onSelectPair={(p) => {
          setSelectedPair(p);
          setSelectedSignalId(null);
        }}
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 space-y-6">
        {activeTab === 'terminal' && (
          <div className="space-y-6">
            {/* Pair Market Summary Card */}
            <div className="bg-[#111827] border border-slate-800 rounded-xl p-4 shadow-xl flex flex-wrap items-center justify-between gap-4">
              {/* Left: Asset Details */}
              <div className="flex items-center space-x-4">
                <div className="flex flex-col">
                  <div className="flex items-center space-x-2">
                    <h2 className="text-2xl font-black text-white tracking-tight">{selectedPair.symbol}</h2>
                    <span className="text-xs text-slate-400 font-medium">{selectedPair.name}</span>
                  </div>
                  <div className="flex items-center space-x-2 mt-1">
                    <span className="text-xl font-bold font-mono text-cyan-400">
                      {formatPrice(
                        pairState?.candles15M?.[pairState.candles15M.length - 1]?.close ||
                          selectedPair.fallbackBasePrice,
                        selectedPair.decimals
                      )}
                    </span>
                    <span className="text-xs text-slate-500 font-mono">LIVE BID/ASK</span>
                  </div>
                </div>
              </div>

              {/* 4-Hour Trend Requirement Indicator */}
              <div className="flex flex-wrap items-center gap-3">
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-2.5 flex items-center space-x-3 text-xs">
                  <div className="space-y-0.5">
                    <div className="text-[10px] text-slate-400 uppercase font-semibold">4H Macro Trend</div>
                    <div
                      className={`font-bold flex items-center space-x-1 ${
                        pairState?.trend4H.direction === 'BULLISH'
                          ? 'text-emerald-400'
                          : pairState?.trend4H.direction === 'BEARISH'
                          ? 'text-rose-400'
                          : 'text-amber-400'
                      }`}
                    >
                      {pairState?.trend4H.direction === 'BULLISH' ? (
                        <TrendingUp className="w-4 h-4" />
                      ) : pairState?.trend4H.direction === 'BEARISH' ? (
                        <TrendingDown className="w-4 h-4" />
                      ) : (
                        <Info className="w-4 h-4" />
                      )}
                      <span>{pairState?.trend4H.direction || 'ANALYZING...'}</span>
                    </div>
                  </div>
                  <div className="border-l border-slate-800 pl-3">
                    <div className="text-[10px] text-slate-400 uppercase font-semibold">15M Signal Filter</div>
                    <div className="font-bold text-slate-200">
                      {pairState?.trend4H.direction === 'BULLISH'
                        ? 'Longs Only Authorized'
                        : pairState?.trend4H.direction === 'BEARISH'
                        ? 'Shorts Only Authorized'
                        : 'Blocked (Consolidation)'}
                    </div>
                  </div>
                </div>

                {/* Retest Requirement Badge */}
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-2.5 flex items-center space-x-3 text-xs">
                  <div>
                    <div className="text-[10px] text-slate-400 uppercase font-semibold">15M Retest Check</div>
                    <div className="font-bold text-cyan-400 flex items-center space-x-1">
                      <ShieldCheck className="w-4 h-4 text-cyan-400" />
                      <span>
                        {currentSignalForChart?.retestConfirmed
                          ? 'Retest Confirmed ✓'
                          : currentSignalForChart?.status === 'PENDING_RETEST'
                          ? 'Retest In Progress...'
                          : 'Monitoring Price Action'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* 1:3 RR Badge */}
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-2.5 flex items-center space-x-2 text-xs">
                  <Target className="w-4 h-4 text-emerald-400" />
                  <div>
                    <div className="text-[10px] text-slate-400 uppercase font-semibold">Risk:Reward</div>
                    <div className="font-bold text-emerald-400 font-mono">Strict 1:3 RR</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Interactive Candlestick Chart */}
            {pairState ? (
              <CandlestickChart
                pair={selectedPair}
                candles15M={pairState.candles15M}
                candles4H={pairState.candles4H}
                signal={currentSignalForChart}
                trend4H={pairState.trend4H}
                timeframe={timeframe}
                onTimeframeChange={setTimeframe}
              />
            ) : (
              <div className="w-full h-[450px] bg-[#111827] border border-slate-800 rounded-xl flex items-center justify-center">
                <div className="text-center space-y-2 text-slate-400 text-xs">
                  <RefreshCw className="w-6 h-6 animate-spin mx-auto text-cyan-400" />
                  <p>Loading live candles and scanning 4H/15M market structure...</p>
                </div>
              </div>
            )}

            {/* Multi-Asset Live Signal Scanner & Filter Matrix */}
            <SignalScanner
              pairs={pairs}
              signals={signals}
              selectedSignalId={selectedSignalId}
              onSelectSignal={handleSelectSignal}
              onSelectPair={(p) => {
                setSelectedPair(p);
                setSelectedSignalId(null);
              }}
              selectedPair={selectedPair}
              isScanning={isScanning}
              onTriggerScan={handleTriggerScan}
              scanIntervalSec={scanIntervalSec}
              onSetScanInterval={setScanIntervalSec}
            />
          </div>
        )}

        {/* Signal Record Book / Performance Ledger Tab */}
        {activeTab === 'journal' && (
          <TradeJournal
            signals={signals}
            stats={stats}
            onClearHistory={() => signalStore.clearAll()}
            onResetSeeds={() => signalStore.resetToSeeds()}
            onSelectSignal={handleSelectSignal}
          />
        )}
      </main>

      {/* Institutional Footer */}
      <footer className="border-t border-slate-800/80 bg-[#070a11] py-4 px-6 text-xs text-slate-500 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          <span>ApexBreakout Signal Engine • Real-time Forex, Gold & BTC Pairs</span>
        </div>
        <div className="flex items-center space-x-4 font-mono text-[11px]">
          <span>4H Macro Filter: ACTIVE</span>
          <span>15M Retest Protocol: ENFORCED</span>
          <span>RR Target: 1:3</span>
        </div>
      </footer>
    </div>
  );
}
