import React, { useRef, useEffect, useState, useMemo } from 'react';
import {
  Candle,
  MarketPair,
  Trendline,
  TrendAnalysis4H,
  BreakoutRetestSignal,
  Timeframe,
} from '../types/market';
import { formatPrice } from '../services/marketPairs';
import { calculateEMA } from '../services/technicalAnalysis';
import {
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Maximize2,
  TrendingUp,
  TrendingDown,
  Info,
} from 'lucide-react';

interface CandlestickChartProps {
  pair: MarketPair;
  candles15M: Candle[];
  candles4H: Candle[];
  signal?: BreakoutRetestSignal | null;
  trend4H: TrendAnalysis4H;
  timeframe: Timeframe;
  onTimeframeChange: (tf: Timeframe) => void;
}

export const CandlestickChart: React.FC<CandlestickChartProps> = ({
  pair,
  candles15M,
  candles4H,
  signal,
  trend4H,
  timeframe,
  onTimeframeChange,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [hoverIndex, setHoverIndex] = useState<number | null>(null);
  const [crosshairPos, setCrosshairPos] = useState<{ x: number; y: number } | null>(null);
  const [zoomLevel, setZoomLevel] = useState<number>(1.0);
  const [panOffset, setPanOffset] = useState<number>(0);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStartX, setDragStartX] = useState<number>(0);

  const candles = timeframe === '15m' ? candles15M : candles4H;

  // Calculate EMAs for display
  const ema50 = useMemo(() => calculateEMA(candles, 50), [candles]);
  const ema200 = useMemo(() => calculateEMA(candles, 200), [candles]);

  // Adjust visible candle window based on zoom and pan
  const visibleCandleCount = Math.max(20, Math.floor(65 / zoomLevel));
  const maxPan = Math.max(0, candles.length - visibleCandleCount);
  const clampedPan = Math.min(Math.max(0, panOffset), maxPan);

  const startIndex = Math.max(0, candles.length - visibleCandleCount - clampedPan);
  const endIndex = Math.min(candles.length, startIndex + visibleCandleCount);
  const visibleCandles = useMemo(() => candles.slice(startIndex, endIndex), [candles, startIndex, endIndex]);

  // Draw chart on canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || visibleCandles.length === 0) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;

    canvas.width = width * dpr;
    canvas.height = height * dpr;
    ctx.scale(dpr, dpr);

    // Padding
    const padTop = 35;
    const padBottom = 35;
    const padRight = 75; // for price axis
    const chartHeight = height - padTop - padBottom;
    const chartWidth = width - padRight;

    // Price bounds
    let minPrice = Math.min(...visibleCandles.map((c) => c.low));
    let maxPrice = Math.max(...visibleCandles.map((c) => c.high));

    // Include TP & SL in price scale if in 15m view with an active signal
    if (timeframe === '15m' && signal) {
      minPrice = Math.min(minPrice, signal.stopLossPrice, signal.takeProfitPrice);
      maxPrice = Math.max(maxPrice, signal.stopLossPrice, signal.takeProfitPrice);
    }

    // Include 50 & 200 EMA in range
    const visibleEma50 = ema50.slice(startIndex, endIndex);
    const visibleEma200 = ema200.slice(startIndex, endIndex);
    visibleEma50.forEach((val) => {
      if (val > 0) {
        minPrice = Math.min(minPrice, val);
        maxPrice = Math.max(maxPrice, val);
      }
    });

    const priceRange = maxPrice - minPrice || 1;
    const buffer = priceRange * 0.08;
    const adjustedMin = minPrice - buffer;
    const adjustedMax = maxPrice + buffer;
    const totalRange = adjustedMax - adjustedMin;

    const getY = (price: number) => {
      return padTop + chartHeight - ((price - adjustedMin) / totalRange) * chartHeight;
    };

    const getPriceFromY = (y: number) => {
      return adjustedMin + ((padTop + chartHeight - y) / chartHeight) * totalRange;
    };

    const barWidth = chartWidth / visibleCandles.length;
    const candleBodyWidth = Math.max(2, barWidth * 0.7);

    // Background gradient
    const bgGrad = ctx.createLinearGradient(0, 0, 0, height);
    bgGrad.addColorStop(0, '#090d16');
    bgGrad.addColorStop(1, '#0e1320');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, width, height);

    // Grid lines - horizontal
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
    ctx.lineWidth = 1;
    const gridSteps = 6;
    for (let i = 0; i <= gridSteps; i++) {
      const y = padTop + (chartHeight / gridSteps) * i;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(chartWidth, y);
      ctx.stroke();

      const priceVal = getPriceFromY(y);
      ctx.fillStyle = '#64748b';
      ctx.font = '10px monospace';
      ctx.textAlign = 'left';
      ctx.fillText(formatPrice(priceVal, pair.decimals), chartWidth + 8, y + 3);
    }

    // Grid lines - vertical time markings
    const timeStep = Math.max(5, Math.floor(visibleCandles.length / 6));
    for (let i = 0; i < visibleCandles.length; i += timeStep) {
      const x = i * barWidth + barWidth / 2;
      ctx.beginPath();
      ctx.moveTo(x, padTop);
      ctx.lineTo(x, padTop + chartHeight);
      ctx.stroke();

      const d = new Date(visibleCandles[i].time * 1000);
      const timeStr =
        timeframe === '4h'
          ? `${d.getMonth() + 1}/${d.getDate()} ${d.getHours()}:00`
          : `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
      ctx.fillStyle = '#64748b';
      ctx.font = '10px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(timeStr, x, height - 12);
    }

    // Draw EMA 50 line (Blue)
    ctx.beginPath();
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([]);
    let ema50Started = false;
    for (let i = 0; i < visibleCandles.length; i++) {
      const globalIdx = startIndex + i;
      const val = ema50[globalIdx];
      if (val > 0) {
        const x = i * barWidth + barWidth / 2;
        const y = getY(val);
        if (!ema50Started) {
          ctx.moveTo(x, y);
          ema50Started = true;
        } else {
          ctx.lineTo(x, y);
        }
      }
    }
    ctx.stroke();

    // Draw EMA 200 line (Purple)
    ctx.beginPath();
    ctx.strokeStyle = '#a855f7';
    ctx.lineWidth = 1.5;
    let ema200Started = false;
    for (let i = 0; i < visibleCandles.length; i++) {
      const globalIdx = startIndex + i;
      const val = ema200[globalIdx];
      if (val > 0) {
        const x = i * barWidth + barWidth / 2;
        const y = getY(val);
        if (!ema200Started) {
          ctx.moveTo(x, y);
          ema200Started = true;
        } else {
          ctx.lineTo(x, y);
        }
      }
    }
    ctx.stroke();

    // Draw 15M Trendline if available and in 15m timeframe
    if (timeframe === '15m' && signal && signal.trendline) {
      const tl = signal.trendline;
      ctx.save();

      // Trendline line
      ctx.strokeStyle = tl.type === 'RESISTANCE' ? '#f59e0b' : '#38bdf8';
      ctx.lineWidth = 2.5;
      ctx.setLineDash([6, 4]);

      let tlStarted = false;
      ctx.beginPath();

      // Plot from start index through to rightmost edge
      const lineStart = Math.max(0, tl.startIndex);
      const lineEnd = candles.length + 5;

      for (let g = lineStart; g <= lineEnd; g++) {
        if (g >= startIndex && g <= endIndex + 5) {
          const x = (g - startIndex) * barWidth + barWidth / 2;
          const priceAtBar = tl.slope * g + tl.intercept;
          const y = getY(priceAtBar);

          if (!tlStarted) {
            ctx.moveTo(x, y);
            tlStarted = true;
          } else {
            ctx.lineTo(x, y);
          }
        }
      }
      ctx.stroke();

      // Trendline Label
      const labelGlobalIdx = Math.min(tl.endIndex + 2, candles.length - 1);
      if (labelGlobalIdx >= startIndex && labelGlobalIdx <= endIndex) {
        const lx = (labelGlobalIdx - startIndex) * barWidth;
        const ly = getY(tl.slope * labelGlobalIdx + tl.intercept) - 14;
        ctx.fillStyle = tl.type === 'RESISTANCE' ? 'rgba(245, 158, 11, 0.9)' : 'rgba(56, 189, 248, 0.9)';
        ctx.font = 'bold 10px monospace';
        ctx.textAlign = 'left';
        ctx.fillText(
          `${tl.type === 'RESISTANCE' ? '▼ 15M DESC RESISTANCE' : '▲ 15M ASC SUPPORT'} (TOUCHES: ${tl.touches})`,
          lx,
          ly
        );
      }
      ctx.restore();

      // Draw Retest Zone shading if retest confirmed or pending
      if (signal.retestCandleTime || signal.status === 'PENDING_RETEST') {
        const retestPriceVal = signal.retestPrice || signal.breakoutPrice;
        const retestZoneY = getY(retestPriceVal);
        const retestZoneHeight = Math.max(14, (signal.riskAmount / totalRange) * chartHeight * 0.35);

        ctx.fillStyle = signal.direction === 'BUY' ? 'rgba(16, 185, 129, 0.12)' : 'rgba(239, 68, 68, 0.12)';
        ctx.fillRect(0, retestZoneY - retestZoneHeight / 2, chartWidth, retestZoneHeight);

        ctx.strokeStyle = signal.direction === 'BUY' ? 'rgba(16, 185, 129, 0.35)' : 'rgba(239, 68, 68, 0.35)';
        ctx.setLineDash([2, 4]);
        ctx.strokeRect(0, retestZoneY - retestZoneHeight / 2, chartWidth, retestZoneHeight);
        ctx.setLineDash([]);
      }
    }

    // Draw Candlesticks
    for (let i = 0; i < visibleCandles.length; i++) {
      const c = visibleCandles[i];
      const globalIdx = startIndex + i;
      const x = i * barWidth + barWidth / 2;

      const isBull = c.close >= c.open;
      const candleColor = isBull ? '#10b981' : '#ef4444';
      const wickColor = isBull ? '#059669' : '#dc2626';

      const openY = getY(c.open);
      const closeY = getY(c.close);
      const highY = getY(c.high);
      const lowY = getY(c.low);

      // Draw Wick
      ctx.strokeStyle = wickColor;
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(x, highY);
      ctx.lineTo(x, lowY);
      ctx.stroke();

      // Draw Body
      ctx.fillStyle = candleColor;
      const bodyTop = Math.min(openY, closeY);
      const bodyHeight = Math.max(2, Math.abs(openY - closeY));
      ctx.fillRect(x - candleBodyWidth / 2, bodyTop, candleBodyWidth, bodyHeight);

      // Check if this is the Breakout candle
      if (timeframe === '15m' && signal && c.time === signal.breakoutCandleTime) {
        ctx.save();
        const markerY = signal.direction === 'BUY' ? lowY + 18 : highY - 18;
        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        if (signal.direction === 'BUY') {
          ctx.moveTo(x, markerY - 8);
          ctx.lineTo(x - 5, markerY);
          ctx.lineTo(x + 5, markerY);
        } else {
          ctx.moveTo(x, markerY + 8);
          ctx.lineTo(x - 5, markerY);
          ctx.lineTo(x + 5, markerY);
        }
        ctx.closePath();
        ctx.fill();

        ctx.font = 'bold 9px monospace';
        ctx.textAlign = 'center';
        ctx.fillText('BREAKOUT', x, signal.direction === 'BUY' ? markerY + 12 : markerY - 8);
        ctx.restore();
      }

      // Check if this is the Retest candle
      if (timeframe === '15m' && signal && signal.retestCandleTime && c.time === signal.retestCandleTime) {
        ctx.save();
        const markerY = signal.direction === 'BUY' ? lowY + 32 : highY - 32;
        ctx.fillStyle = '#06b6d4';
        ctx.beginPath();
        ctx.arc(x, markerY, 4, 0, Math.PI * 2);
        ctx.fill();

        ctx.font = 'bold 9px monospace';
        ctx.textAlign = 'center';
        ctx.fillText('RETEST CONFIRMED', x, signal.direction === 'BUY' ? markerY + 12 : markerY - 8);
        ctx.restore();
      }
    }

    // Draw Trade Execution Levels (Entry, SL, TP) if in 15m and signal exists
    if (timeframe === '15m' && signal) {
      // 1. Entry Line (Cyan)
      const entryY = getY(signal.entryPrice);
      ctx.save();
      ctx.strokeStyle = '#06b6d4';
      ctx.lineWidth = 1.8;
      ctx.setLineDash([4, 2]);
      ctx.beginPath();
      ctx.moveTo(0, entryY);
      ctx.lineTo(chartWidth, entryY);
      ctx.stroke();

      ctx.fillStyle = '#06b6d4';
      ctx.fillRect(chartWidth, entryY - 10, padRight, 20);
      ctx.fillStyle = '#02182b';
      ctx.font = 'bold 10px monospace';
      ctx.textAlign = 'left';
      ctx.fillText(`ENTRY`, chartWidth + 6, entryY + 3);
      ctx.restore();

      // 2. Stop Loss Line (Red -1R)
      const slY = getY(signal.stopLossPrice);
      ctx.save();
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 1.8;
      ctx.setLineDash([5, 3]);
      ctx.beginPath();
      ctx.moveTo(0, slY);
      ctx.lineTo(chartWidth, slY);
      ctx.stroke();

      ctx.fillStyle = '#ef4444';
      ctx.fillRect(chartWidth, slY - 10, padRight, 20);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 10px monospace';
      ctx.textAlign = 'left';
      ctx.fillText(`SL -1R`, chartWidth + 6, slY + 3);
      ctx.restore();

      // 3. Take Profit Line (Emerald +3R)
      const tpY = getY(signal.takeProfitPrice);
      ctx.save();
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 2.0;
      ctx.setLineDash([5, 3]);
      ctx.beginPath();
      ctx.moveTo(0, tpY);
      ctx.lineTo(chartWidth, tpY);
      ctx.stroke();

      ctx.fillStyle = '#10b981';
      ctx.fillRect(chartWidth, tpY - 10, padRight, 20);
      ctx.fillStyle = '#022c22';
      ctx.font = 'bold 10px monospace';
      ctx.textAlign = 'left';
      ctx.fillText(`TP +3R`, chartWidth + 6, tpY + 3);
      ctx.restore();
    }

    // Draw Live Price Line
    const latestCandle = candles[candles.length - 1];
    if (latestCandle) {
      const liveY = getY(latestCandle.close);
      ctx.save();
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.5)';
      ctx.lineWidth = 1;
      ctx.setLineDash([2, 2]);
      ctx.beginPath();
      ctx.moveTo(0, liveY);
      ctx.lineTo(chartWidth, liveY);
      ctx.stroke();

      // Live price pill
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(chartWidth, liveY - 9, padRight, 18);
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 1;
      ctx.strokeRect(chartWidth, liveY - 9, padRight, 18);

      ctx.fillStyle = '#f59e0b';
      ctx.font = 'bold 10px monospace';
      ctx.textAlign = 'left';
      ctx.fillText(formatPrice(latestCandle.close, pair.decimals), chartWidth + 6, liveY + 3);
      ctx.restore();
    }

    // Draw Crosshair if hovering
    if (crosshairPos && crosshairPos.x <= chartWidth) {
      ctx.save();
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.25)';
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 3]);

      // Vertical line
      ctx.beginPath();
      ctx.moveTo(crosshairPos.x, padTop);
      ctx.lineTo(crosshairPos.x, padTop + chartHeight);
      ctx.stroke();

      // Horizontal line
      ctx.beginPath();
      ctx.moveTo(0, crosshairPos.y);
      ctx.lineTo(chartWidth, crosshairPos.y);
      ctx.stroke();

      // Price badge on Y axis
      const hoveredPrice = getPriceFromY(crosshairPos.y);
      ctx.fillStyle = '#334155';
      ctx.fillRect(chartWidth, crosshairPos.y - 8, padRight, 16);
      ctx.fillStyle = '#f8fafc';
      ctx.font = '10px monospace';
      ctx.textAlign = 'left';
      ctx.fillText(formatPrice(hoveredPrice, pair.decimals), chartWidth + 6, crosshairPos.y + 3);
      ctx.restore();
    }
  }, [
    visibleCandles,
    candles,
    timeframe,
    signal,
    trend4H,
    zoomLevel,
    panOffset,
    crosshairPos,
    pair.decimals,
    pair.pipSize,
    ema50,
    ema200,
  ]);

  // Handle Mouse Interactions
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setCrosshairPos({ x, y });

    // Panning
    if (isDragging) {
      const delta = Math.floor((e.clientX - dragStartX) / 6);
      setPanOffset((prev) => Math.min(Math.max(0, prev - delta), maxPan));
      setDragStartX(e.clientX);
    }

    // Determine hovered candle
    const padRight = 75;
    const chartWidth = rect.width - padRight;
    if (x >= 0 && x <= chartWidth && visibleCandles.length > 0) {
      const barWidth = chartWidth / visibleCandles.length;
      const idx = Math.floor(x / barWidth);
      if (idx >= 0 && idx < visibleCandles.length) {
        setHoverIndex(startIndex + idx);
      }
    } else {
      setHoverIndex(null);
    }
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDragging(true);
    setDragStartX(e.clientX);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleMouseLeave = () => {
    setIsDragging(false);
    setCrosshairPos(null);
    setHoverIndex(null);
  };

  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    if (e.deltaY < 0) {
      setZoomLevel((z) => Math.min(2.5, z * 1.15));
    } else {
      setZoomLevel((z) => Math.max(0.6, z * 0.85));
    }
  };

  const hoveredCandle = hoverIndex !== null && candles[hoverIndex] ? candles[hoverIndex] : candles[candles.length - 1];

  return (
    <div
      ref={containerRef}
      className="flex flex-col bg-[#0b0f19] border border-slate-800 rounded-xl overflow-hidden shadow-2xl relative select-none"
    >
      {/* Top Toolbar */}
      <div className="flex flex-wrap items-center justify-between px-4 py-3 bg-[#111827]/80 border-b border-slate-800/80 gap-3">
        {/* Left: Pair Info & Timeframe */}
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2">
            <span className="text-lg font-bold tracking-tight text-white">{pair.symbol}</span>
            <span
              className={`text-[11px] font-semibold uppercase px-2 py-0.5 rounded tracking-wider ${
                pair.category === 'gold'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  : pair.category === 'crypto'
                  ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
                  : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
              }`}
            >
              {pair.category}
            </span>
          </div>

          {/* Timeframe Selector */}
          <div className="flex items-center bg-slate-900 border border-slate-800 rounded-lg p-0.5">
            <button
              onClick={() => onTimeframeChange('15m')}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-all ${
                timeframe === '15m'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              15M Signal Chart
            </button>
            <button
              onClick={() => onTimeframeChange('4h')}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-all ${
                timeframe === '4h'
                  ? 'bg-purple-500 text-white font-bold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              4H Macro Trend
            </button>
          </div>
        </div>

        {/* Center: 4H Market Trend Compliance Status */}
        <div className="hidden lg:flex items-center space-x-2 px-3 py-1 bg-slate-900/90 rounded-lg border border-slate-800 text-xs">
          <span className="text-slate-400 font-medium">4H Trend Rule:</span>
          <div
            className={`flex items-center space-x-1.5 font-bold ${
              trend4H.direction === 'BULLISH'
                ? 'text-emerald-400'
                : trend4H.direction === 'BEARISH'
                ? 'text-rose-400'
                : 'text-amber-400'
            }`}
          >
            {trend4H.direction === 'BULLISH' ? (
              <TrendingUp className="w-3.5 h-3.5" />
            ) : trend4H.direction === 'BEARISH' ? (
              <TrendingDown className="w-3.5 h-3.5" />
            ) : (
              <Info className="w-3.5 h-3.5" />
            )}
            <span>{trend4H.direction}</span>
          </div>
          <span className="text-slate-500">|</span>
          <span className="text-slate-300">
            {trend4H.direction === 'BULLISH'
              ? 'Only LONG Breakout & Retest Valid'
              : trend4H.direction === 'BEARISH'
              ? 'Only SHORT Breakdown & Retest Valid'
              : 'Signals Blocked (Neutral)'}
          </span>
        </div>

        {/* Right: Zoom & Reset Controls */}
        <div className="flex items-center space-x-1.5">
          <button
            onClick={() => setZoomLevel((z) => Math.min(2.5, z * 1.2))}
            title="Zoom In"
            className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 transition-colors"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setZoomLevel((z) => Math.max(0.6, z * 0.8))}
            title="Zoom Out"
            className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 transition-colors"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => {
              setZoomLevel(1.0);
              setPanOffset(0);
            }}
            title="Reset View"
            className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* OHLC Bar */}
      {hoveredCandle && (
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 px-4 py-1.5 bg-[#0e1320] text-xs font-mono border-b border-slate-800/60 text-slate-400">
          <div>
            <span className="text-slate-500 mr-1">TIME:</span>
            <span className="text-slate-300">
              {new Date(hoveredCandle.time * 1000).toLocaleString('en-US', {
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              })}
            </span>
          </div>
          <div>
            <span className="text-slate-500 mr-1">O:</span>
            <span className="text-slate-200">{formatPrice(hoveredCandle.open, pair.decimals)}</span>
          </div>
          <div>
            <span className="text-slate-500 mr-1">H:</span>
            <span className="text-emerald-400">{formatPrice(hoveredCandle.high, pair.decimals)}</span>
          </div>
          <div>
            <span className="text-slate-500 mr-1">L:</span>
            <span className="text-rose-400">{formatPrice(hoveredCandle.low, pair.decimals)}</span>
          </div>
          <div>
            <span className="text-slate-500 mr-1">C:</span>
            <span
              className={
                hoveredCandle.close >= hoveredCandle.open ? 'text-emerald-400 font-semibold' : 'text-rose-400 font-semibold'
              }
            >
              {formatPrice(hoveredCandle.close, pair.decimals)}
            </span>
          </div>
          <div className="hidden sm:inline-block">
            <span className="text-slate-500 mr-1">VOL:</span>
            <span className="text-slate-300">{hoveredCandle.volume.toLocaleString()}</span>
          </div>
          <div className="ml-auto flex items-center space-x-3 text-[11px]">
            <span className="flex items-center text-sky-400 font-sans">
              <span className="w-2 h-0.5 bg-sky-400 inline-block mr-1"></span> EMA 50
            </span>
            <span className="flex items-center text-purple-400 font-sans">
              <span className="w-2 h-0.5 bg-purple-400 inline-block mr-1"></span> EMA 200
            </span>
            {timeframe === '15m' && signal && (
              <span className="flex items-center text-amber-400 font-sans">
                <span className="w-2.5 h-0.5 bg-amber-400 inline-block mr-1"></span> 15M Trendline
              </span>
            )}
          </div>
        </div>
      )}

      {/* Main Canvas Area */}
      <div className="relative w-full h-[460px] sm:h-[500px] cursor-crosshair">
        <canvas
          ref={canvasRef}
          onMouseMove={handleMouseMove}
          onMouseDown={handleMouseDown}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseLeave}
          onWheel={handleWheel}
          className="w-full h-full block"
        />

        {/* Legend Overlay for Breakout & Retest */}
        {timeframe === '15m' && signal && (
          <div className="absolute bottom-3 left-3 bg-slate-900/95 backdrop-blur-md border border-slate-700/80 rounded-xl p-3 text-xs text-slate-300 space-y-1.5 pointer-events-none shadow-2xl max-w-sm">
            <div className="flex items-center justify-between pb-1 border-b border-slate-800">
              <div className="font-bold flex items-center space-x-1.5 text-white">
                <span
                  className={`w-2.5 h-2.5 rounded-full ${
                    signal.status === 'PROFIT_HIT'
                      ? 'bg-emerald-400'
                      : signal.status === 'LOSS_HIT'
                      ? 'bg-rose-400'
                      : 'bg-cyan-400 animate-pulse'
                  }`}
                />
                <span className="text-[11px] font-black tracking-wide uppercase">
                  {signal.direction} SIGNAL ({signal.timeIntervalGiven || '15M INTERVAL'})
                </span>
              </div>

              {/* Explicit VALID / NOT VALID Indicator */}
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded font-mono ${
                  signal.isValid
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : 'bg-slate-800 text-slate-400 border border-slate-700'
                }`}
              >
                {signal.isValid ? '✓ STILL VALID' : '✗ NOT VALID (CLOSED)'}
              </span>
            </div>

            {/* Time Given Stamp */}
            <div className="text-[10px] font-mono text-cyan-300 flex items-center justify-between">
              <span>Given: {new Date(signal.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
              <span className="text-slate-400">Interval: 15M Candle</span>
            </div>

            <div className="text-[11px] text-slate-300 leading-snug">
              {signal.validityReason || signal.retestNote}
            </div>

            <div className="pt-1.5 flex items-center justify-between text-[11px] font-mono border-t border-slate-800">
              <span className="text-cyan-400 font-semibold">Entry: {formatPrice(signal.entryPrice, pair.decimals)}</span>
              <span className="text-rose-400 font-semibold">SL: {formatPrice(signal.stopLossPrice, pair.decimals)}</span>
              <span className="text-emerald-400 font-bold">TP: {formatPrice(signal.takeProfitPrice, pair.decimals)}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
