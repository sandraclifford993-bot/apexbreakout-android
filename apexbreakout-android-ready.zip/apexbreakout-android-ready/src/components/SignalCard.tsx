import React, { useState } from 'react';
import { BreakoutRetestSignal } from '../types/market';
import { formatPrice } from '../services/marketPairs';
import { formatRelativeTime, formatExactDateTime } from '../services/signalStore';
import {
  TrendingUp,
  TrendingDown,
  Clock,
  CheckCircle2,
  XCircle,
  Copy,
  Check,
  Calculator,
  ShieldAlert,
  Target,
  ArrowRight,
  Sparkles,
  AlertTriangle,
  Timer,
  CheckCheck,
} from 'lucide-react';

interface SignalCardProps {
  signal: BreakoutRetestSignal;
  decimals?: number;
  isSelected?: boolean;
  onSelect?: () => void;
}

export const SignalCard: React.FC<SignalCardProps> = ({
  signal,
  decimals = 4,
  isSelected = false,
  onSelect,
}) => {
  const [copied, setCopied] = useState(false);
  const [showCalculator, setShowCalculator] = useState(false);
  const [accountBalance, setAccountBalance] = useState<number>(10000);
  const [riskPercent, setRiskPercent] = useState<number>(1.0);

  const isBuy = signal.direction === 'BUY';
  const isProfitHit = signal.status === 'PROFIT_HIT';
  const isLossHit = signal.status === 'LOSS_HIT';
  const isActive = signal.status === 'ACTIVE';
  const isPending = signal.status === 'PENDING_RETEST';

  const isNew = signal.isNewSignal || Date.now() - signal.createdAt < 1000 * 60 * 60 * 2;

  // Calculate position sizing
  const riskDollar = (accountBalance * riskPercent) / 100;
  let lotSize = 0;
  if (signal.riskAmount > 0) {
    if (signal.category === 'forex') {
      lotSize = Math.max(0.01, Math.round((riskDollar / (signal.riskPips * 10)) * 100) / 100);
    } else if (signal.category === 'gold') {
      lotSize = Math.max(0.01, Math.round((riskDollar / (signal.riskAmount * 100)) * 100) / 100);
    } else {
      lotSize = Math.max(0.001, Math.round((riskDollar / signal.riskAmount) * 1000) / 1000);
    }
  }

  // Calculate price progress toward TP (0% at Entry, 100% at TP, -33% at SL)
  let progressPercent = 0;
  if (signal.riskAmount > 0) {
    const diff = isBuy ? signal.currentPrice - signal.entryPrice : signal.entryPrice - signal.currentPrice;
    progressPercent = Math.min(100, Math.max(-33.3, (diff / signal.rewardAmount) * 100));
  }

  const handleCopy = () => {
    const text = `🎯 [APEX SIGNAL] ${signal.pairSymbol} ${signal.direction}\n` +
      `• Given At: ${formatExactDateTime(signal.createdAt)} (${formatRelativeTime(signal.createdAt)})\n` +
      `• Signal Time Interval: ${signal.timeIntervalGiven || '15M (15-Minute Candle)'}\n` +
      `• 4H Macro Trend: ${signal.trend4H}\n` +
      `• Status & Validity: ${signal.isValid ? 'STILL VALID' : 'NOT VALID (CLOSED)'} - ${signal.status}\n` +
      `• Entry: ${signal.entryPrice}\n` +
      `• Stop Loss: ${signal.stopLossPrice} (-${signal.riskPips} pips)\n` +
      `• Take Profit: ${signal.takeProfitPrice} (+${signal.rewardPips} pips)\n` +
      `• Risk-to-Reward: 1:3 Strict RR\n` +
      `• Result / P&L: ${signal.status === 'PROFIT_HIT' ? '+3.0R (Profit Hit)' : signal.status === 'LOSS_HIT' ? '-1.0R (Loss Hit)' : `${signal.currentRMultiple}R`}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      onClick={onSelect}
      className={`group relative rounded-xl border transition-all duration-200 cursor-pointer overflow-hidden ${
        isSelected
          ? 'bg-slate-900 border-cyan-500 shadow-xl shadow-cyan-500/10 ring-1 ring-cyan-500/50'
          : 'bg-[#111827]/90 border-slate-800 hover:border-slate-700 hover:bg-slate-900/80 shadow-md'
      }`}
    >
      {/* Top Banner Status & Validity Bar */}
      <div
        className={`px-4 py-2 border-b flex flex-wrap items-center justify-between text-xs font-semibold gap-2 ${
          isProfitHit
            ? 'bg-emerald-950/60 border-emerald-800/60 text-emerald-300'
            : isLossHit
            ? 'bg-rose-950/60 border-rose-800/60 text-rose-300'
            : isPending
            ? 'bg-amber-950/60 border-amber-800/60 text-amber-300'
            : 'bg-cyan-950/60 border-cyan-800/60 text-cyan-300'
        }`}
      >
        <div className="flex items-center space-x-2">
          {/* New Signal Badge */}
          {isNew && (
            <span className="flex items-center space-x-1 px-1.5 py-0.5 rounded bg-amber-500 text-slate-950 text-[10px] font-black uppercase tracking-wider animate-pulse">
              <Sparkles className="w-2.5 h-2.5 fill-current" />
              <span>NEW SIGNAL</span>
            </span>
          )}

          {isProfitHit && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
          {isLossHit && <XCircle className="w-4 h-4 text-rose-400" />}
          {isActive && <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />}
          {isPending && <Clock className="w-4 h-4 text-amber-400 animate-spin" />}

          <span className="tracking-wide">
            {isProfitHit
              ? 'PROFIT HIT (+3.0R RECORDED)'
              : isLossHit
              ? 'LOSS HIT (-1.0R STOPPED)'
              : isPending
              ? 'AWAITING 15M RETEST BOUNCE'
              : 'ACTIVE SIGNAL (1:3 RR IN PLAY)'}
          </span>
        </div>

        {/* Time Given & Interval */}
        <div className="flex items-center space-x-2 text-[11px] font-mono">
          <span className="text-cyan-400 font-bold">15M Interval</span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-300" title={formatExactDateTime(signal.createdAt)}>
            {formatRelativeTime(signal.createdAt)}
          </span>
        </div>
      </div>

      {/* Main Card Content */}
      <div className="p-4 space-y-4">
        {/* Header: Pair, Direction, and Timing Stamp */}
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xl font-bold text-white tracking-tight">{signal.pairSymbol}</span>
              <span
                className={`text-[11px] font-bold px-2 py-0.5 rounded tracking-wide ${
                  isBuy
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                }`}
              >
                {isBuy ? '▲ BUY / LONG' : '▼ SELL / SHORT'}
              </span>
            </div>

            {/* Time Interval & Timing Information */}
            <div className="flex flex-wrap items-center gap-x-2 gap-y-1 mt-1 text-xs text-slate-400">
              <span className="flex items-center text-slate-300 font-mono">
                <Timer className="w-3.5 h-3.5 text-cyan-400 mr-1 inline" />
                Interval: <strong className="text-cyan-300 ml-1">{signal.timeIntervalGiven || '15M'}</strong>
              </span>
              <span>•</span>
              <span className="flex items-center text-slate-300">
                {signal.trend4H === 'BULLISH' ? (
                  <TrendingUp className="w-3.5 h-3.5 text-emerald-400 mr-1 inline" />
                ) : (
                  <TrendingDown className="w-3.5 h-3.5 text-rose-400 mr-1 inline" />
                )}
                4H: <strong className="text-white ml-1">{signal.trend4H}</strong>
              </span>
            </div>
            <div className="text-[11px] text-slate-500 font-mono mt-0.5">
              Given at: {formatExactDateTime(signal.createdAt)}
            </div>
          </div>

          {/* Current Live P&L or Outcome */}
          <div className="text-right font-mono">
            <div
              className={`text-base font-bold ${
                isProfitHit
                  ? 'text-emerald-400'
                  : isLossHit
                  ? 'text-rose-400'
                  : signal.currentRMultiple >= 0
                  ? 'text-emerald-400'
                  : 'text-rose-400'
              }`}
            >
              {isProfitHit
                ? '+3.00 R'
                : isLossHit
                ? '-1.00 R'
                : `${signal.currentRMultiple >= 0 ? '+' : ''}${signal.currentRMultiple.toFixed(2)} R`}
            </div>
            <div className="text-xs text-slate-400">
              {signal.currentPnlPips >= 0 ? `+${signal.currentPnlPips}` : signal.currentPnlPips} pips
            </div>
          </div>
        </div>

        {/* PROMINENT VALIDITY BADGE & REASON */}
        <div
          className={`p-2.5 rounded-lg border text-xs flex items-start space-x-2 ${
            signal.isValid
              ? 'bg-emerald-950/40 border-emerald-800/60 text-emerald-200'
              : isProfitHit
              ? 'bg-slate-900 border-emerald-800/40 text-emerald-300'
              : 'bg-slate-900 border-rose-800/40 text-rose-300'
          }`}
        >
          {signal.isValid ? (
            <CheckCheck className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
          )}
          <div className="space-y-0.5">
            <div className="font-bold flex items-center space-x-1.5 uppercase tracking-wide text-[11px]">
              <span>STATUS:</span>
              <span className={signal.isValid ? 'text-emerald-400 underline font-black' : 'text-slate-300 font-semibold'}>
                {signal.isValid ? 'STILL VALID FOR TRADING' : 'NO LONGER VALID (CLOSED RECORD)'}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 leading-snug">
              {signal.validityReason ||
                (signal.isValid
                  ? 'Signal is currently valid. Price is active between Entry and TP/SL.'
                  : 'Signal concluded. Recorded in permanent trade archive.')}
            </p>
          </div>
        </div>

        {/* 15M Retest Note */}
        <div className="text-xs bg-slate-950/60 border border-slate-800/80 rounded-lg p-2.5 text-slate-300 flex items-start space-x-2">
          <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 mt-0.5 shrink-0" />
          <span className="leading-snug">{signal.retestNote}</span>
        </div>

        {/* Signal Execution Levels Grid (Entry, SL, TP) */}
        <div className="grid grid-cols-3 gap-2 bg-[#090d16] border border-slate-800 rounded-lg p-3">
          {/* Entry */}
          <div className="space-y-0.5">
            <div className="text-[10px] uppercase font-bold text-cyan-400 tracking-wider flex items-center">
              <span>ENTRY POINT</span>
            </div>
            <div className="font-mono text-sm font-bold text-white">
              {formatPrice(signal.entryPrice, decimals)}
            </div>
            <div className="text-[10px] text-slate-400">15M retest confirmed</div>
          </div>

          {/* Stop Loss (-1R) */}
          <div className="space-y-0.5 border-l border-slate-800 pl-2.5">
            <div className="text-[10px] uppercase font-bold text-rose-400 tracking-wider flex items-center">
              <ShieldAlert className="w-2.5 h-2.5 mr-1" />
              <span>STOP LOSS (-1R)</span>
            </div>
            <div className="font-mono text-sm font-bold text-rose-400">
              {formatPrice(signal.stopLossPrice, decimals)}
            </div>
            <div className="text-[10px] text-slate-400">Risk: {signal.riskPips} pips</div>
          </div>

          {/* Take Profit (+3R) */}
          <div className="space-y-0.5 border-l border-slate-800 pl-2.5">
            <div className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider flex items-center">
              <Target className="w-2.5 h-2.5 mr-1" />
              <span>TAKE PROFIT (+3R)</span>
            </div>
            <div className="font-mono text-sm font-bold text-emerald-400">
              {formatPrice(signal.takeProfitPrice, decimals)}
            </div>
            <div className="text-[10px] text-emerald-500 font-semibold">Target: {signal.rewardPips} pips</div>
          </div>
        </div>

        {/* Risk-Reward Visual Track Bar */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-[11px] font-mono text-slate-400">
            <span className="text-rose-400">SL: -1R</span>
            <span className="text-cyan-400">Entry: 0R</span>
            <span className="text-emerald-400 font-bold">TP: +3R (1:3 Target)</span>
          </div>
          <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden relative border border-slate-800 flex">
            {/* Left 25% represents SL zone */}
            <div className="w-1/4 h-full bg-rose-950/40 border-r border-slate-700/60" />
            {/* Right 75% represents 1:3 profit zone */}
            <div className="w-3/4 h-full bg-emerald-950/40 relative">
              {/* Current Progress bar */}
              <div
                className={`h-full transition-all duration-300 ${
                  isProfitHit
                    ? 'w-full bg-emerald-500'
                    : isLossHit
                    ? 'w-0'
                    : progressPercent >= 0
                    ? 'bg-gradient-to-r from-cyan-500 to-emerald-400'
                    : 'bg-rose-500'
                }`}
                style={{
                  width: isProfitHit ? '100%' : isLossHit ? '0%' : `${Math.max(0, Math.min(100, progressPercent))}%`,
                }}
              />
            </div>
          </div>
        </div>

        {/* Position Size Calculator Dropdown */}
        {showCalculator && (
          <div
            onClick={(e) => e.stopPropagation()}
            className="p-3 bg-slate-950 border border-slate-800 rounded-lg space-y-3 text-xs"
          >
            <div className="font-bold text-slate-200 flex items-center justify-between">
              <span className="flex items-center">
                <Calculator className="w-3.5 h-3.5 text-cyan-400 mr-1.5" />
                1:3 RR Position Sizing Calculator
              </span>
              <span className="text-cyan-400 font-mono">1% Risk Rule</span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Account Balance ($)</label>
                <input
                  type="number"
                  value={accountBalance}
                  onChange={(e) => setAccountBalance(Number(e.target.value) || 0)}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-white font-mono text-xs focus:outline-none focus:border-cyan-500"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Risk Per Trade (%)</label>
                <input
                  type="number"
                  step="0.5"
                  value={riskPercent}
                  onChange={(e) => setRiskPercent(Number(e.target.value) || 1)}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-white font-mono text-xs focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <div className="p-2.5 bg-slate-900/90 rounded border border-slate-800 flex items-center justify-between font-mono">
              <div>
                <div className="text-[10px] text-slate-400 uppercase">Risk Amount:</div>
                <div className="text-rose-400 font-bold">${riskDollar.toFixed(2)}</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-400 uppercase">Target Gain (+3R):</div>
                <div className="text-emerald-400 font-bold">${(riskDollar * 3).toFixed(2)}</div>
              </div>
              <div className="text-right">
                <div className="text-[10px] text-slate-400 uppercase">
                  {signal.category === 'forex' ? 'Lot Size' : 'Units'}:
                </div>
                <div className="text-cyan-400 font-bold text-sm">
                  {lotSize} {signal.category === 'forex' ? 'Lots' : signal.pairSymbol.split('/')[0]}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Card Footer Actions */}
        <div className="flex items-center justify-between pt-1 border-t border-slate-800/80 text-xs">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setShowCalculator(!showCalculator);
            }}
            className="flex items-center text-slate-400 hover:text-cyan-400 transition-colors py-1"
          >
            <Calculator className="w-3.5 h-3.5 mr-1" />
            <span>{showCalculator ? 'Hide Calculator' : 'Risk & Lots'}</span>
          </button>

          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleCopy();
              }}
              className="flex items-center space-x-1 px-2.5 py-1 bg-slate-800/80 hover:bg-slate-700 rounded text-slate-300 hover:text-white transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>

            <span className="flex items-center text-cyan-400 font-medium group-hover:translate-x-0.5 transition-transform">
              <span>View Chart</span>
              <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
