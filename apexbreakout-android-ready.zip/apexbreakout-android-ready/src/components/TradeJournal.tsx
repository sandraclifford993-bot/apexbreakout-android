import React, { useState } from 'react';
import { BreakoutRetestSignal, PerformanceStats } from '../types/market';
import { formatPrice } from '../services/marketPairs';
import { formatRelativeTime, formatExactDateTime } from '../services/signalStore';
import {
  Download,
  Trash2,
  RotateCcw,
  Trophy,
  CheckCircle2,
  XCircle,
  Percent,
  TrendingUp,
  BarChart3,
  Calendar,
  Clock,
  Shield,
  Layers,
  Sparkles,
  AlertTriangle,
  CheckCheck,
  Timer,
  Eye,
  X,
} from 'lucide-react';

interface TradeJournalProps {
  signals: BreakoutRetestSignal[];
  stats: PerformanceStats;
  onClearHistory: () => void;
  onResetSeeds: () => void;
  onSelectSignal: (signal: BreakoutRetestSignal) => void;
}

export const TradeJournal: React.FC<TradeJournalProps> = ({
  signals,
  stats,
  onClearHistory,
  onResetSeeds,
  onSelectSignal,
}) => {
  const [filter, setFilter] = useState<'ALL' | 'VALID' | 'PROFIT_HIT' | 'LOSS_HIT'>('ALL');
  const [inspectedSignal, setInspectedSignal] = useState<BreakoutRetestSignal | null>(null);

  const filteredSignals = signals.filter((s) => {
    if (filter === 'ALL') return true;
    if (filter === 'VALID') return s.isValid;
    if (filter === 'PROFIT_HIT') return s.status === 'PROFIT_HIT';
    if (filter === 'LOSS_HIT') return s.status === 'LOSS_HIT';
    return true;
  });

  const validCount = signals.filter((s) => s.isValid).length;

  // Export ledger to CSV
  const handleExportCSV = () => {
    const headers = [
      'Signal ID',
      'Pair',
      'Category',
      'Direction',
      'Signal Interval',
      '4H Macro Trend',
      'Given Time (Exact)',
      'Validity Status',
      'Is Still Valid',
      'Entry Price',
      'Stop Loss Price (-1R)',
      'Take Profit Price (+3R)',
      'Risk Pips',
      'Reward Pips',
      'R-Multiple',
      'Trade Outcome Status',
      'Duration',
      'Resolved Date',
      'Strategy Retest Notes',
    ];

    const rows = signals.map((s) => [
      s.id,
      s.pairSymbol,
      s.category,
      s.direction,
      s.timeIntervalGiven || '15M',
      s.trend4H,
      formatExactDateTime(s.createdAt),
      s.validityStatus,
      s.isValid ? 'YES - STILL VALID' : 'NO - CLOSED',
      s.entryPrice,
      s.stopLossPrice,
      s.takeProfitPrice,
      s.riskPips,
      s.rewardPips,
      s.currentRMultiple,
      s.status,
      s.durationFormatted || '',
      s.resolvedAt ? formatExactDateTime(s.resolvedAt) : '',
      `"${(s.retestNote || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `apex_signals_ledger_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Performance Scorecard Overview */}
      <div className="grid grid-cols-2 lg:grid-cols-6 gap-3">
        {/* Win Rate */}
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Win Rate</span>
            <Percent className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-400">
            {stats.winRate}%
          </div>
          <div className="text-[11px] text-slate-500">
            {stats.profitHits} Won / {stats.lossHits} Lost
          </div>
        </div>

        {/* Net R Profit */}
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Net Return (R)</span>
            <Trophy className="w-4 h-4 text-amber-400" />
          </div>
          <div
            className={`text-2xl font-bold font-mono ${
              stats.netR >= 0 ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {stats.netR >= 0 ? `+${stats.netR} R` : `${stats.netR} R`}
          </div>
          <div className="text-[11px] text-slate-500">
            Strict 1:3 RR (+3R / -1R)
          </div>
        </div>

        {/* Profit Hits */}
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Profit Hits</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white">
            {stats.profitHits}
          </div>
          <div className="text-[11px] text-emerald-500/80 font-medium">
            +{(stats.profitHits * 3).toFixed(1)}R Generated
          </div>
        </div>

        {/* Loss Hits */}
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Loss Hits</span>
            <XCircle className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white">
            {stats.lossHits}
          </div>
          <div className="text-[11px] text-rose-500/80 font-medium">
            -{(stats.lossHits * 1).toFixed(1)}R Capped Risk
          </div>
        </div>

        {/* Profit Factor */}
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Profit Factor</span>
            <BarChart3 className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-cyan-400">
            {stats.profitFactor.toFixed(2)}
          </div>
          <div className="text-[11px] text-slate-500">Gross Win / Gross Loss</div>
        </div>

        {/* Total Net Pips */}
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Net Pips</span>
            <TrendingUp className="w-4 h-4 text-indigo-400" />
          </div>
          <div
            className={`text-2xl font-bold font-mono ${
              stats.netPips >= 0 ? 'text-indigo-400' : 'text-rose-400'
            }`}
          >
            {stats.netPips >= 0 ? `+${stats.netPips}` : stats.netPips}
          </div>
          <div className="text-[11px] text-slate-500">Forex, Gold & BTC</div>
        </div>
      </div>

      {/* Complete Historical Signal Ledger */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden shadow-xl">
        {/* Table Header Bar */}
        <div className="p-4 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center space-x-2">
              <span>Permanent Signal Archive & Audit Log</span>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-mono font-bold border border-cyan-500/30">
                {signals.length} Signals Recorded
              </span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Records every signal ever issued, time interval, validity status, and resolution (Profit Hit / Stop Loss Hit)
            </p>
          </div>

          {/* Filters & Export */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center space-x-1 bg-slate-900 border border-slate-800 rounded-lg p-0.5 text-xs">
              <button
                onClick={() => setFilter('ALL')}
                className={`px-3 py-1 rounded font-medium ${
                  filter === 'ALL' ? 'bg-slate-800 text-white font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                All Records ({signals.length})
              </button>
              <button
                onClick={() => setFilter('VALID')}
                className={`flex items-center space-x-1 px-3 py-1 rounded font-medium ${
                  filter === 'VALID'
                    ? 'bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <CheckCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Still Valid ({validCount})</span>
              </button>
              <button
                onClick={() => setFilter('PROFIT_HIT')}
                className={`flex items-center space-x-1 px-3 py-1 rounded font-medium ${
                  filter === 'PROFIT_HIT'
                    ? 'bg-emerald-500/20 text-emerald-300 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Profit Hit +3R ({stats.profitHits})</span>
              </button>
              <button
                onClick={() => setFilter('LOSS_HIT')}
                className={`flex items-center space-x-1 px-3 py-1 rounded font-medium ${
                  filter === 'LOSS_HIT'
                    ? 'bg-rose-500/20 text-rose-300 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <XCircle className="w-3.5 h-3.5 text-rose-400" />
                <span>Loss Hit -1R ({stats.lossHits})</span>
              </button>
            </div>

            <button
              onClick={handleExportCSV}
              className="flex items-center space-x-1.5 px-3 py-1.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors border border-slate-700"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400" />
              <span>Export CSV Ledger</span>
            </button>

            <button
              onClick={onResetSeeds}
              title="Reset to Verified Sample Records"
              className="p-1.5 text-slate-400 hover:text-slate-200 bg-slate-800/80 hover:bg-slate-700 rounded-lg transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={onClearHistory}
              title="Clear Signal History"
              className="p-1.5 text-rose-400 hover:text-rose-300 bg-rose-950/40 hover:bg-rose-900/60 rounded-lg border border-rose-800/50 transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Ledger Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-900/90 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">When Given</th>
                <th className="py-3 px-4">Time Interval</th>
                <th className="py-3 px-4">Pair</th>
                <th className="py-3 px-4">Direction</th>
                <th className="py-3 px-4">Validity State</th>
                <th className="py-3 px-4">Entry</th>
                <th className="py-3 px-4">Stop Loss (-1R)</th>
                <th className="py-3 px-4">Take Profit (+3R)</th>
                <th className="py-3 px-4">Outcome Status</th>
                <th className="py-3 px-4 text-center">Audit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredSignals.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-8 text-center text-slate-500 font-sans">
                    No signals found matching this filter.
                  </td>
                </tr>
              ) : (
                filteredSignals.map((s) => {
                  const isWon = s.status === 'PROFIT_HIT';
                  const isLost = s.status === 'LOSS_HIT';
                  const isActive = s.status === 'ACTIVE';
                  const isPending = s.status === 'PENDING_RETEST';
                  const isNew = s.isNewSignal || Date.now() - s.createdAt < 1000 * 60 * 60 * 2;

                  return (
                    <tr
                      key={s.id}
                      onClick={() => onSelectSignal(s)}
                      className="hover:bg-slate-800/40 transition-colors cursor-pointer"
                    >
                      {/* When Given */}
                      <td className="py-3 px-4 text-slate-300 whitespace-nowrap">
                        <div className="flex items-center space-x-1.5">
                          {isNew && (
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                          )}
                          <span className="font-bold text-white">
                            {formatRelativeTime(s.createdAt)}
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-500">
                          {formatExactDateTime(s.createdAt)}
                        </div>
                      </td>

                      {/* Time Interval Given */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-cyan-950/60 text-cyan-300 border border-cyan-800/60">
                          <Timer className="w-3 h-3 mr-1 text-cyan-400" />
                          {s.timeIntervalGiven || '15M'}
                        </span>
                        <div className="text-[10px] text-slate-400 mt-0.5">
                          4H: {s.trend4H}
                        </div>
                      </td>

                      {/* Pair */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className="font-bold text-white mr-1.5">{s.pairSymbol}</span>
                        <span className="text-[10px] uppercase text-slate-500">{s.category}</span>
                      </td>

                      {/* Direction */}
                      <td className="py-3 px-4 whitespace-nowrap font-sans">
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold ${
                            s.direction === 'BUY'
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          }`}
                        >
                          {s.direction === 'BUY' ? '▲ BUY' : '▼ SELL'}
                        </span>
                      </td>

                      {/* Explicit Validity State */}
                      <td className="py-3 px-4 whitespace-nowrap font-sans">
                        {s.isValid ? (
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/50">
                            <CheckCheck className="w-3 h-3 mr-1 text-emerald-400" />
                            STILL VALID
                          </span>
                        ) : (
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-800 text-slate-400 border border-slate-700">
                            NOT VALID (CLOSED)
                          </span>
                        )}
                        <div className="text-[10px] text-slate-500 mt-0.5 truncate max-w-[140px]" title={s.validityReason}>
                          {s.durationFormatted || (s.isValid ? 'In market' : 'Resolved')}
                        </div>
                      </td>

                      {/* Entry */}
                      <td className="py-3 px-4 text-white font-semibold whitespace-nowrap">
                        {s.entryPrice}
                      </td>

                      {/* SL */}
                      <td className="py-3 px-4 text-rose-400 whitespace-nowrap">
                        {s.stopLossPrice}{' '}
                        <span className="text-[10px] text-slate-500">(-{s.riskPips}p)</span>
                      </td>

                      {/* TP */}
                      <td className="py-3 px-4 text-emerald-400 font-semibold whitespace-nowrap">
                        {s.takeProfitPrice}{' '}
                        <span className="text-[10px] text-emerald-500/80">(+{s.rewardPips}p)</span>
                      </td>

                      {/* Outcome Status */}
                      <td className="py-3 px-4 whitespace-nowrap font-sans">
                        {isWon && (
                          <span className="inline-flex items-center px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[11px] font-bold">
                            <CheckCircle2 className="w-3 h-3 mr-1" />
                            PROFIT HIT (+3R)
                          </span>
                        )}
                        {isLost && (
                          <span className="inline-flex items-center px-2 py-0.5 rounded bg-rose-500/20 text-rose-400 border border-rose-500/40 text-[11px] font-bold">
                            <XCircle className="w-3 h-3 mr-1" />
                            LOSS HIT (-1R)
                          </span>
                        )}
                        {isActive && (
                          <span className="inline-flex items-center px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-[11px] font-bold animate-pulse">
                            ACTIVE ({s.currentRMultiple >= 0 ? `+${s.currentRMultiple}R` : `${s.currentRMultiple}R`})
                          </span>
                        )}
                        {isPending && (
                          <span className="inline-flex items-center px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[11px] font-bold">
                            AWAITING RETEST
                          </span>
                        )}
                      </td>

                      {/* View & Audit Action */}
                      <td className="py-3 px-4 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center space-x-1.5">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setInspectedSignal(s);
                            }}
                            title="Audit Signal Details"
                            className="p-1 text-slate-400 hover:text-cyan-400 bg-slate-800 rounded transition-colors"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onSelectSignal(s);
                            }}
                            className="px-2 py-0.5 text-[11px] bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500 hover:text-slate-950 font-sans font-medium rounded transition-colors"
                          >
                            Chart
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Signal Audit Modal */}
      {inspectedSignal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#111827] border border-slate-800 rounded-2xl max-w-xl w-full p-6 shadow-2xl relative space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center space-x-2">
                <span className="text-lg font-black text-white">{inspectedSignal.pairSymbol}</span>
                <span
                  className={`px-2 py-0.5 rounded text-xs font-bold ${
                    inspectedSignal.direction === 'BUY'
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                  }`}
                >
                  {inspectedSignal.direction} SIGNAL
                </span>
                <span
                  className={`px-2 py-0.5 rounded text-xs font-bold font-mono ${
                    inspectedSignal.isValid
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {inspectedSignal.isValid ? 'STILL VALID' : 'NOT VALID (CLOSED)'}
                </span>
              </div>
              <button
                onClick={() => setInspectedSignal(null)}
                className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Audit Details Grid */}
            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3 bg-slate-900/90 p-3 rounded-xl border border-slate-800 font-mono">
                <div>
                  <div className="text-[10px] text-slate-500 uppercase">When Given:</div>
                  <div className="text-white font-bold">{formatExactDateTime(inspectedSignal.createdAt)}</div>
                  <div className="text-cyan-400 text-[11px]">{formatRelativeTime(inspectedSignal.createdAt)}</div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500 uppercase">Time Interval:</div>
                  <div className="text-white font-bold">{inspectedSignal.timeIntervalGiven || '15M Candle'}</div>
                  <div className="text-slate-400 text-[11px]">Macro: {inspectedSignal.trend4H}</div>
                </div>
              </div>

              {/* Validity Audit Banner */}
              <div
                className={`p-3 rounded-xl border ${
                  inspectedSignal.isValid
                    ? 'bg-emerald-950/40 border-emerald-800/60 text-emerald-300'
                    : inspectedSignal.status === 'PROFIT_HIT'
                    ? 'bg-emerald-950/30 border-emerald-800/40 text-emerald-300'
                    : 'bg-rose-950/30 border-rose-800/40 text-rose-300'
                }`}
              >
                <div className="font-bold uppercase text-[11px] mb-1">
                  Validity Status: {inspectedSignal.isValid ? 'STILL VALID FOR TRADING' : 'NOT VALID (CLOSED)'}
                </div>
                <div className="text-slate-300 leading-snug">
                  {inspectedSignal.validityReason}
                </div>
              </div>

              {/* Execution Levels */}
              <div className="grid grid-cols-3 gap-2 bg-slate-950 p-3 rounded-xl border border-slate-800 font-mono text-center">
                <div>
                  <div className="text-[10px] text-slate-500 uppercase">Entry Point</div>
                  <div className="text-white font-bold text-sm">{inspectedSignal.entryPrice}</div>
                </div>
                <div>
                  <div className="text-[10px] text-rose-400 uppercase">Stop Loss (-1R)</div>
                  <div className="text-rose-400 font-bold text-sm">{inspectedSignal.stopLossPrice}</div>
                  <div className="text-[10px] text-slate-500">Risk: {inspectedSignal.riskPips}p</div>
                </div>
                <div>
                  <div className="text-[10px] text-emerald-400 uppercase">Take Profit (+3R)</div>
                  <div className="text-emerald-400 font-bold text-sm">{inspectedSignal.takeProfitPrice}</div>
                  <div className="text-[10px] text-emerald-500">Target: {inspectedSignal.rewardPips}p</div>
                </div>
              </div>

              {/* Retest & Structural Notes */}
              <div className="bg-slate-900/90 p-3 rounded-xl border border-slate-800 space-y-1">
                <div className="font-bold text-slate-300 uppercase text-[10px]">15M Retest Verification:</div>
                <div className="text-slate-400 leading-snug">{inspectedSignal.retestNote}</div>
                {inspectedSignal.resolvedAt && (
                  <div className="pt-2 text-[11px] text-slate-500 font-mono border-t border-slate-800">
                    Trade Concluded At: {formatExactDateTime(inspectedSignal.resolvedAt)} ({inspectedSignal.durationFormatted})
                  </div>
                )}
              </div>
            </div>

            <div className="pt-2 flex items-center justify-end space-x-2">
              <button
                onClick={() => {
                  onSelectSignal(inspectedSignal);
                  setInspectedSignal(null);
                }}
                className="px-4 py-2 bg-cyan-500 text-slate-950 font-bold rounded-lg hover:bg-cyan-400 transition-colors text-xs"
              >
                Inspect on Chart
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
