import React, { useState } from 'react';
import { MarketPair, BreakoutRetestSignal, MarketCategory, SignalStatus } from '../types/market';
import { SignalCard } from './SignalCard';
import {
  Search,
  Filter,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  Sparkles,
  Layers,
  Activity,
  CheckCircle2,
  XCircle,
  Clock,
} from 'lucide-react';

interface SignalScannerProps {
  pairs: MarketPair[];
  signals: BreakoutRetestSignal[];
  selectedSignalId: string | null;
  onSelectSignal: (signal: BreakoutRetestSignal) => void;
  onSelectPair: (pair: MarketPair) => void;
  selectedPair: MarketPair;
  isScanning: boolean;
  onTriggerScan: () => void;
  scanIntervalSec: number;
  onSetScanInterval: (sec: number) => void;
}

export const SignalScanner: React.FC<SignalScannerProps> = ({
  pairs,
  signals,
  selectedSignalId,
  onSelectSignal,
  onSelectPair,
  selectedPair,
  isScanning,
  onTriggerScan,
  scanIntervalSec,
  onSetScanInterval,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<MarketCategory | 'ALL'>('ALL');
  const [statusFilter, setStatusFilter] = useState<SignalStatus | 'VALID' | 'ALL'>('ALL');

  // Filter signals
  const filteredSignals = signals.filter((sig) => {
    if (categoryFilter !== 'ALL' && sig.category !== categoryFilter) return false;
    if (statusFilter === 'VALID') {
      if (!sig.isValid) return false;
    } else if (statusFilter !== 'ALL' && sig.status !== statusFilter) {
      return false;
    }
    if (
      searchQuery &&
      !sig.pairSymbol.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !sig.pairId.toLowerCase().includes(searchQuery.toLowerCase())
    ) {
      return false;
    }
    return true;
  });

  const activeCount = signals.filter((s) => s.status === 'ACTIVE').length;
  const pendingCount = signals.filter((s) => s.status === 'PENDING_RETEST').length;
  const profitHitCount = signals.filter((s) => s.status === 'PROFIT_HIT').length;
  const lossHitCount = signals.filter((s) => s.status === 'LOSS_HIT').length;

  return (
    <div className="flex flex-col space-y-4">
      {/* Scanner Control Bar */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl p-4 shadow-xl space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Title & Live Status */}
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-lg bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
              <Activity className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center space-x-2">
                <span>Live Breakout & Retest Scanner</span>
                <span className="text-xs font-mono font-medium px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  4H Trend + 15M Retest
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Scanning Forex, Gold & BTC pairs for confirmed trendline breakout bounces with 1:3 RR
              </p>
            </div>
          </div>

          {/* Scan Actions & Interval Selector */}
          <div className="flex items-center space-x-2">
            <div className="flex items-center space-x-1.5 text-xs text-slate-400 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1">
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              <span>Interval:</span>
              <select
                value={scanIntervalSec}
                onChange={(e) => onSetScanInterval(Number(e.target.value))}
                className="bg-transparent text-white font-medium focus:outline-none cursor-pointer"
              >
                <option value={10} className="bg-slate-900 text-white">10s (Fast)</option>
                <option value={30} className="bg-slate-900 text-white">30s (Normal)</option>
                <option value={60} className="bg-slate-900 text-white">60s (Slow)</option>
                <option value={0} className="bg-slate-900 text-white">Manual Only</option>
              </select>
            </div>

            <button
              onClick={onTriggerScan}
              disabled={isScanning}
              className={`flex items-center space-x-1.5 px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
                isScanning
                  ? 'bg-slate-800 text-slate-400 cursor-not-allowed'
                  : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-md shadow-cyan-500/20 active:scale-95'
              }`}
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
              <span>{isScanning ? 'Scanning...' : 'Scan Now'}</span>
            </button>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800/80">
          {/* Category Tabs */}
          <div className="flex items-center space-x-1 bg-slate-900/90 p-1 rounded-lg border border-slate-800 text-xs">
            {(['ALL', 'forex', 'gold', 'crypto'] as const).map((cat) => (
              <button
                key={cat}
                onClick={() => setCategoryFilter(cat)}
                className={`px-3 py-1 rounded font-medium transition-colors ${
                  categoryFilter === cat
                    ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/30'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {cat === 'ALL' ? 'All Assets' : cat === 'forex' ? 'Forex Pairs' : cat === 'gold' ? 'Gold (XAU)' : 'BTC & Crypto'}
              </button>
            ))}
          </div>

          {/* Status Tabs */}
          <div className="flex items-center space-x-1 bg-slate-900/90 p-1 rounded-lg border border-slate-800 text-xs">
            <button
              onClick={() => setStatusFilter('ALL')}
              className={`px-2.5 py-1 rounded font-medium ${
                statusFilter === 'ALL'
                  ? 'bg-slate-800 text-white font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All Records ({signals.length})
            </button>
            <button
              onClick={() => setStatusFilter('VALID')}
              className={`flex items-center space-x-1 px-2.5 py-1 rounded font-medium ${
                statusFilter === 'VALID'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              <span>Still Valid ({signals.filter((s) => s.isValid).length})</span>
            </button>
            <button
              onClick={() => setStatusFilter('ACTIVE')}
              className={`flex items-center space-x-1 px-2.5 py-1 rounded font-medium ${
                statusFilter === 'ACTIVE'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
              <span>In Play ({activeCount})</span>
            </button>
            <button
              onClick={() => setStatusFilter('PENDING_RETEST')}
              className={`flex items-center space-x-1 px-2.5 py-1 rounded font-medium ${
                statusFilter === 'PENDING_RETEST'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Clock className="w-3 h-3 text-amber-400" />
              <span>Retest Pending ({pendingCount})</span>
            </button>
            <button
              onClick={() => setStatusFilter('PROFIT_HIT')}
              className={`flex items-center space-x-1 px-2.5 py-1 rounded font-medium ${
                statusFilter === 'PROFIT_HIT'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              <span>Profit Hit ({profitHitCount})</span>
            </button>
            <button
              onClick={() => setStatusFilter('LOSS_HIT')}
              className={`flex items-center space-x-1 px-2.5 py-1 rounded font-medium ${
                statusFilter === 'LOSS_HIT'
                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <XCircle className="w-3 h-3 text-rose-400" />
              <span>Loss Hit ({lossHitCount})</span>
            </button>
          </div>

          {/* Search Input */}
          <div className="relative min-w-[160px]">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-500" />
            <input
              type="text"
              placeholder="Search pair..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>
        </div>
      </div>

      {/* Quick Pair Selector Bar */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-1 no-scrollbar">
        <span className="text-xs text-slate-500 shrink-0 uppercase tracking-wider font-semibold pl-1">
          Market Quick Switch:
        </span>
        {pairs.map((p) => (
          <button
            key={p.id}
            onClick={() => onSelectPair(p)}
            className={`shrink-0 px-2.5 py-1 rounded-lg text-xs font-mono font-medium border transition-colors ${
              selectedPair.id === p.id
                ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 shadow-sm'
                : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:bg-slate-800 hover:text-slate-200'
            }`}
          >
            {p.symbol}
          </button>
        ))}
      </div>

      {/* Signals Grid */}
      {filteredSignals.length === 0 ? (
        <div className="p-8 text-center bg-[#111827]/50 border border-slate-800 rounded-xl space-y-3">
          <Layers className="w-8 h-8 text-slate-600 mx-auto" />
          <h3 className="text-sm font-semibold text-slate-300">No signals match current filters</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Try switching category or trigger a fresh multi-asset market scan to detect new 15m breakout & retest opportunities.
          </p>
          <button
            onClick={onTriggerScan}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white rounded-lg transition-colors"
          >
            Run Deep Market Scan
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filteredSignals.map((signal) => {
            const pair = pairs.find((p) => p.id === signal.pairId);
            return (
              <SignalCard
                key={signal.id}
                signal={signal}
                decimals={pair?.decimals || 4}
                isSelected={selectedSignalId === signal.id}
                onSelect={() => onSelectSignal(signal)}
              />
            );
          })}
        </div>
      )}
    </div>
  );
};
