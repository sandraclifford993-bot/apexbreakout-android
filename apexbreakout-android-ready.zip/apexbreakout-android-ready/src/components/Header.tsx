import React, { useState } from 'react';
import { MarketPair } from '../types/market';
import { formatPrice } from '../services/marketPairs';
import { soundEffects } from '../services/soundEffects';
import {
  Volume2,
  VolumeX,
  BookOpen,
  Radio,
  Zap,
  TrendingUp,
  TrendingDown,
  X,
  CheckCircle2,
  ShieldAlert,
} from 'lucide-react';

interface HeaderProps {
  pairs: MarketPair[];
  selectedPair: MarketPair;
  onSelectPair: (pair: MarketPair) => void;
  activeTab: 'terminal' | 'journal' | 'rules';
  onTabChange: (tab: 'terminal' | 'journal' | 'rules') => void;
}

export const Header: React.FC<HeaderProps> = ({
  pairs,
  selectedPair,
  onSelectPair,
  activeTab,
  onTabChange,
}) => {
  const [soundOn, setSoundOn] = useState(soundEffects.isEnabled());
  const [showRulesModal, setShowRulesModal] = useState(false);

  const toggleSound = () => {
    const next = !soundOn;
    setSoundOn(next);
    soundEffects.setEnabled(next);
  };

  return (
    <header className="bg-[#0b0f19] border-b border-slate-800 sticky top-0 z-40 backdrop-blur-md">
      {/* Top Banner Ticker */}
      <div className="bg-[#070a11] border-b border-slate-800/80 px-4 py-1.5 flex items-center justify-between overflow-x-auto no-scrollbar text-xs font-mono">
        <div className="flex items-center space-x-6 shrink-0">
          <div className="flex items-center space-x-1.5 text-slate-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-[11px] font-sans font-bold uppercase tracking-wider text-slate-300">
              LIVE MARKETS:
            </span>
          </div>

          {pairs.slice(0, 6).map((p) => {
            const price = p.currentPrice || p.fallbackBasePrice;
            const isSelected = p.id === selectedPair.id;

            return (
              <button
                key={p.id}
                onClick={() => onSelectPair(p)}
                className={`flex items-center space-x-1.5 hover:text-white transition-colors cursor-pointer ${
                  isSelected ? 'text-cyan-400 font-bold' : 'text-slate-400'
                }`}
              >
                <span className="text-slate-300">{p.symbol}:</span>
                <span className="text-white">{formatPrice(price, p.decimals)}</span>
              </button>
            );
          })}
        </div>

        <div className="hidden md:flex items-center space-x-4 text-[11px] text-slate-400 font-sans shrink-0">
          <span className="flex items-center text-emerald-400">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1.5" />
            4H Trend + 15M Retest Engine Active
          </span>
          <span className="text-slate-600">|</span>
          <span className="text-cyan-400 font-semibold font-mono">1:3 RR Standard</span>
        </div>
      </div>

      {/* Main Header Bar */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
        {/* Brand Logo & Title */}
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-600 to-emerald-400 flex items-center justify-center shadow-lg shadow-cyan-500/20 text-slate-950 font-black">
            <Zap className="w-5 h-5 fill-slate-950" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-lg font-black text-white tracking-tight">ApexBreakout</h1>
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                PRO SIGNAL SYSTEM
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">
              15M Trendline Breakout & Retest with 4H Trend Alignment • Strict 1:3 RR
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl p-1 text-xs">
          <button
            onClick={() => onTabChange('terminal')}
            className={`px-3.5 py-1.5 rounded-lg font-semibold transition-all ${
              activeTab === 'terminal'
                ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Live Terminal
          </button>
          <button
            onClick={() => onTabChange('journal')}
            className={`px-3.5 py-1.5 rounded-lg font-semibold transition-all ${
              activeTab === 'journal'
                ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Signal Record Book
          </button>
          <button
            onClick={() => setShowRulesModal(true)}
            className="px-3.5 py-1.5 rounded-lg font-semibold text-slate-400 hover:text-cyan-400 transition-colors flex items-center space-x-1"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Strategy Rules</span>
          </button>
        </div>

        {/* Right Tools: Sound & Alert Status */}
        <div className="flex items-center space-x-2">
          <button
            onClick={toggleSound}
            title={soundOn ? 'Sound Alerts On' : 'Sound Alerts Muted'}
            className={`p-2 rounded-lg border transition-colors ${
              soundOn
                ? 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/20'
                : 'bg-slate-900 border-slate-800 text-slate-500 hover:text-slate-300'
            }`}
          >
            {soundOn ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Strategy Rules Modal */}
      {showRulesModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#111827] border border-slate-800 rounded-2xl max-w-2xl w-full p-6 shadow-2xl relative space-y-5 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center space-x-2">
                <BookOpen className="w-5 h-5 text-cyan-400" />
                <h3 className="text-base font-bold text-white">
                  Strategy Specification: 4H Trend + 15M Breakout & Retest
                </h3>
              </div>
              <button
                onClick={() => setShowRulesModal(false)}
                className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs text-slate-300 leading-relaxed">
              {/* Rule 1 */}
              <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 space-y-1.5">
                <div className="font-bold text-white flex items-center text-sm">
                  <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-xs mr-2 font-mono">
                    1
                  </span>
                  4-Hour Market Trend Determination
                </div>
                <p className="text-slate-400 pl-7">
                  The macro trend is computed on the <strong>4-Hour (4H)</strong> timeframe using EMA 50 & EMA 200 along with structural pivot highs/lows.
                  If 4H is <strong className="text-emerald-400">Bullish</strong>, only LONG signals are authorized.
                  If 4H is <strong className="text-rose-400">Bearish</strong>, only SHORT signals are authorized.
                  If Neutral/Chop, signals are paused to prevent false breakouts.
                </p>
              </div>

              {/* Rule 2 */}
              <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 space-y-1.5">
                <div className="font-bold text-white flex items-center text-sm">
                  <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-xs mr-2 font-mono">
                    2
                  </span>
                  15-Minute Trendline Breakout
                </div>
                <p className="text-slate-400 pl-7">
                  On the <strong>15-Minute (15M)</strong> timeframe, the system plots descending resistance lines for Bullish setups or ascending support lines for Bearish setups.
                  The breakout candle must close decisively through the trendline.
                </p>
              </div>

              {/* Rule 3 */}
              <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 space-y-1.5">
                <div className="font-bold text-white flex items-center text-sm">
                  <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-xs mr-2 font-mono">
                    3
                  </span>
                  Mandatory 15-Minute Pullback Retest Before Signal Fires
                </div>
                <p className="text-slate-400 pl-7">
                  <strong>The signal will NEVER fire immediately upon breakout.</strong> Price must pull back and retest the broken trendline/breakout zone.
                  The retest candle must reject the level and close in the direction of the 4H trend. Only after this retest confirmation is the signal generated!
                </p>
              </div>

              {/* Rule 4 */}
              <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 space-y-1.5">
                <div className="font-bold text-white flex items-center text-sm">
                  <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-xs mr-2 font-mono">
                    4
                  </span>
                  Strict 1:3 Risk to Reward Ratio (Entry, SL, TP)
                </div>
                <p className="text-slate-400 pl-7">
                  • <strong>Entry Point:</strong> Close of confirmed 15m retest candle.<br />
                  • <strong>Stop Loss (-1R):</strong> Placed below the retest swing low (for BUY) or above retest swing high (for SELL) with volatility buffer.<br />
                  • <strong>Take Profit (+3R):</strong> Strictly computed as <code className="text-emerald-400">Entry ± (3.0 × Risk)</code>.<br />
                  • <strong>Outcome Recording:</strong> The system automatically records whether each signal hit Take Profit (+3R profit hit) or Stop Loss (-1R loss hit).
                </p>
              </div>
            </div>

            <div className="pt-2 text-right">
              <button
                onClick={() => setShowRulesModal(false)}
                className="px-4 py-2 bg-cyan-500 text-slate-950 font-bold rounded-lg hover:bg-cyan-400 transition-colors text-xs"
              >
                Got It, Return to Terminal
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
