import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.apexbreakout.signals',
  appName: 'ApexBreakout',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
