# Build ApexBreakout as an Android APK

This ZIP has been prepared with Capacitor configuration. It is source code, not a compiled APK.

## Build using a computer
1. Install Node.js (LTS) and Android Studio with an Android SDK.
2. Extract this ZIP and open a terminal in the extracted folder.
3. Run:
   ```bash
   npm install
   npm run build
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
4. In Android Studio, wait for Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK is typically at `android/app/build/outputs/apk/debug/app-debug.apk`.

## Build in a cloud IDE
Upload this ZIP to a cloud development environment that supports Node.js and Android SDK/Gradle. Run the commands above, then download the generated `app-debug.apk`.

## Notes
- Internet-based market data or AI features may require valid API keys and network access; check `.env.example` and the project README.
- A successful APK build does not guarantee trading signals are accurate. Test the app and its signals in demo mode before relying on them.
